#include <stdio.h>
#include <string.h>

#include "data/image.h"
#include "nu_port.h"
#include "port/hz.h"

static int failures;

#define CHECK(cond) \
    do { \
        if (!(cond)) { \
            fprintf(stderr, "%s:%d: check failed: %s\n", __FILE__, __LINE__, #cond); \
            failures++; \
        } \
    } while (0)

static unsigned char ram[32];

static void *host(uint32_t addr)
{
    return addr >= 0x1000 && addr < 0x1000 + sizeof(ram) ? &ram[addr - 0x1000] : NULL;
}

int main(void)
{
    CHECK(nw_hz == 50 && nw_hz_line_ns() == 64000u);
    CHECK(nw_hz_set(60) == 60 && nw_hz == 60 && nw_hz_line_ns() == 63556u);
    CHECK(NW_HZ(0.02f, 0.016666668f) == 0.016666668f && NW_HZ(6, 5) == 5);
    CHECK(nw_hz_set(55) == 50 && NW_HZ(6, 5) == 6);

    float gravity = -0.0072f;
    memcpy(&ram[0], &gravity, 4);
    ram[4] = 10;
    ram[6] = 0xDC, ram[7] = 0x05;                       /* 1500 */
    ram[8] = 0x5D, ram[9] = ram[10] = ram[11] = 0xFF;   /* -163 */
    ram[12] = 7;
    const NwHzPatch patches[] = {
        { "GRAVITY", 0x1000, 0, 0, 0, -0.0072f, -0.005f },
        { "frames", 0x1004, 1, 10, 12, 0.0f, 0.0f },
        { "idle", 0x1006, 2, 1500, 1800, 0.0f, 0.0f },
        { "turn", 0x1008, 4, 0xFFFFFF5Du, 0xFFFFFF78u, 0.0f, 0.0f },
        { "not retail", 0x100C, 1, 5, 6, 0.0f, 0.0f },
        { "no host", 0x2000, 1, 5, 6, 0.0f, 0.0f },
    };
    CHECK(nw_hz_apply(patches, sizeof patches / sizeof patches[0], host) == 2);
    memcpy(&gravity, &ram[0], 4);
    CHECK(gravity == -0.005f && ram[4] == 12 && ram[6] == 0x08 && ram[7] == 0x07);
    CHECK(ram[8] == 0x78 && ram[11] == 0xFF && ram[12] == 7);
    CHECK(nw_hz_apply(patches, sizeof patches / sizeof patches[0], host) == 6 && ram[4] == 12);

    unsigned char elf[52] = { 0x7f, 'E', 'L', 'F', 1, 1, 1 };
    elf[18] = 8;  /* EM_MIPS */
    elf[28] = 52; /* e_phoff */
    elf[42] = 32; /* e_phentsize */
    NwImageStats stats;
    char err[512];
    CHECK(!nw_image_load_disc(&nw_image_tables, "PAL v9.99", elf, sizeof(elf), &stats, err, sizeof(err)) &&
          strstr(err, "has no PAL v9.99"));
    if (!nw_image_load_disc(&nw_image_tables, "USA v1.00", elf, sizeof(elf), &stats, err, sizeof(err))) {
        fprintf(stderr, "data image of USA v1.00: %s\n", err);
        return 1;
    }
    for (unsigned i = 0; i < nw_image_tables.nseeds; i++) {
        const NwImageSeed *s = &nw_image_tables.seeds[i];
        CHECK(memcmp(nw_image_host(s->addr), s->bytes, s->size) == 0);
    }
    CHECK(nw_image_tables.nseeds > 0 && nw_hz_patch() == 0);
    nw_image_free();

    if (failures) {
        fprintf(stderr, "%d check(s) failed\n", failures);
        return 1;
    }
    return 0;
}
