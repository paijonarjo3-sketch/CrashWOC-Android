#include <stdio.h>
#include <string.h>

#include <SDL3/SDL.h>

#include "gfx/gsc.h"
#include "gfx/mtl.h"
#include "gfx/packet.h"
#include "gfx/vif.h"

#include "gsc_builder.h"
#include "skin_builder.h"
#include "vif_builder.h"

static int failures;

#define CHECK(cond) \
    do { \
        if (!(cond)) { \
            fprintf(stderr, "%s:%d: CHECK(%s) failed; last error: %s\n", __FILE__, __LINE__, #cond, SDL_GetError()); \
            failures++; \
        } \
    } while (0)

#define CHECK_FAILS(call, text) \
    do { \
        if (call) { \
            fprintf(stderr, "%s:%d: %s succeeded, expected \"%s\"\n", __FILE__, __LINE__, #call, text); \
            failures++; \
        } else if (!SDL_strstr(SDL_GetError(), text)) { \
            fprintf(stderr, "%s:%d: %s: error \"%s\", expected \"%s\"\n", __FILE__, __LINE__, #call, SDL_GetError(), \
                    text); \
            failures++; \
        } \
    } while (0)

static uint32_t fbits(float f)
{
    uint32_t u;
    memcpy(&u, &f, 4);
    return u;
}

static void test_batch(void)
{
    uint32_t g[40] = {
        0x60000009, 0, 0, 0,                    /* RET, 9 quadwords, no VIF codes */
        0x6C0180D2, 0x8004, 0x30024000, 0x512, 0, /* the strip GIF tag, NLOOP 4 */
        0x01000103,                             /* STCYCL 3,1 */
        0x6C048003,                             /* UNPACK V4-32 x4 to VU 3 */
    };
    float xyz[4][3] = { { 0, 0, 0 }, { 1, 0, 0 }, { 0, 1, 0 }, { 1, 1, -0.0f } };
    uint32_t *p = g + 11;
    for (int i = 0; i < 4; i++) {
        *p++ = fbits(xyz[i][0]);
        *p++ = fbits(xyz[i][1]);
        *p++ = fbits(xyz[i][2]);
        *p++ = i < 2 ? 0x3F808001u : 0x3F800000u; /* w = the normal's x, ADC in the low half */
    }
    *p++ = 0x65048004; /* UNPACK V2-16 x4 to VU 4 */
    for (int i = 0; i < 4; i++) {
        *p++ = (uint32_t)(uint16_t)(i * 4096) | (uint32_t)(uint16_t)(-i * 2048) << 16;
    }
    *p++ = 0x6E04C005; /* UNPACK V4-8 unsigned x4 to VU 5 */
    for (int i = 0; i < 4; i++) {
        *p++ = 0x80404000u + (uint32_t)i;
    }
    *p++ = 0x01000101; /* STCYCL 1,1 */
    *p++ = 0x14000300; /* MSCAL 0x300 */
    *p++ = 0;          /* NOP to the quadword */
    CHECK(p == g + 40);

    NwVifMesh m = { 0 };
    CHECK(nw_vif_decode(&m, g, sizeof(g)));
    CHECK(m.nverts == 4 && m.ntris == 2 && m.nbatches == 1);
    if (m.nverts == 4 && m.ntris == 2) {
        static const uint32_t tris[6] = { 0, 1, 2, 1, 3, 2 };
        CHECK(memcmp(m.tris, tris, sizeof(tris)) == 0);
        CHECK(m.verts[1].pos[0] == 1.0f && fbits(m.verts[3].pos[2]) == 0x80000000u);
        CHECK(fbits(m.verts[0].pos[3]) == 0x3F808001u);
        CHECK(m.verts[2].tex[0] == 8192 && m.verts[2].tex[1] == -4096 && m.verts[2].tex[2] == 0);
        CHECK(m.verts[3].col[0] == 3 && m.verts[3].col[1] == 0x40 && m.verts[3].col[3] == 0x80);
    }
    /* The hash recipe, pinned in tests/test_gsc_hash.py too. */
    char line[256];
    nw_gsc_obj_line(0, &m, line, sizeof(line));
    CHECK(strcmp(line, "OBJ 0 batches=1 verts=4 tris=2 "
                       "vtx=5ff61ee696e31a115059cd16ee188d6eb4aa25b17e7a40ac6583f6893c700941 "
                       "idx=a55571c9db30026e44ac0bdd7674d9c597d8254732feb18418f3aaf8a5b4f418") == 0);
    CHECK(nw_vif_decode(&m, g, sizeof(g)));
    CHECK(m.nverts == 8 && m.ntris == 4 && m.tris[6] == 4);
    nw_vif_free(&m);
}

/* Vertices on a 1/8 grid, exact as V4-32 floats and as V4-16 offsets against a 4096 span. */
static void make_strip(VifVtx *v, uint32_t n, int seed)
{
    for (uint32_t i = 0; i < n; i++) {
        v[i] = (VifVtx){
            .x = (float)(i / 2) * 0.25f - 3.0f, .y = (float)(i & 1) * 0.5f + 1.0f, .z = (float)seed * 0.125f,
            .nx = 1.0f, .u = (float)i * 0.25f, .v = (float)(i & 1) - 0.5f, .ny = 0.5f, .nz = -0.25f,
            .rgba = { (uint8_t)i, (uint8_t)(0x80 - i), 0x40, 0x7F },
        };
    }
}

static bool same_vertices(const NwVifMesh *m, uint32_t first, const VifVtx *v, const bool *adc, uint32_t n,
                          bool packed, bool fast)
{
    for (uint32_t i = 0; i < n; i++) {
        const NwVifVertex *d = &m->verts[first + i];
        uint32_t w = packed ? 0 : (vif_fbits(v[i].nx) & 0xFFFF0000u) | (adc[i] ? 0x8001u : 0);
        int16_t tex[4] = { (int16_t)(int32_t)(v[i].u * 4096.0f), (int16_t)(int32_t)(v[i].v * 4096.0f),
                           fast ? 0 : (int16_t)(int32_t)(v[i].ny * 4096.0f), fast ? 0 : (int16_t)(int32_t)(v[i].nz * 4096.0f) };
        if (d->pos[0] != v[i].x || d->pos[1] != v[i].y || d->pos[2] != v[i].z || vif_fbits(d->pos[3]) != w ||
            memcmp(d->tex, tex, sizeof(tex)) != 0 || memcmp(d->col, v[i].rgba, 4) != 0) {
            fprintf(stderr, "vertex %u differs\n", first + i);
            return false;
        }
    }
    return true;
}

static bool decode(NwVifMesh *m, VifBuild *b)
{
    return nw_vif_decode(m, b->buf, b->len);
}

static void test_strips(void)
{
    VifVtx v[7];
    const bool adc[7] = { 1, 1, 0, 0, 1, 1, 0 };
    make_strip(v, 7, 0);
    VifBuild b;
    vif_begin(&b);
    vif_batch(&b, v, adc, 7, 0);
    vif_end(&b, 0);
    NwVifMesh m = { 0 };
    CHECK(decode(&m, &b));
    static const uint32_t tris[9] = { 0, 1, 2, 1, 3, 2, 4, 5, 6 };
    CHECK(m.nbatches == 1 && m.nverts == 7 && m.ntris == 3);
    CHECK(m.ntris == 3 && memcmp(m.tris, tris, sizeof(tris)) == 0);
    CHECK(same_vertices(&m, 0, v, adc, 7, false, false));
    nw_vif_free(&m);
    vif_free(&b);
}

/* A strip longer than 42 goes out in chunks of 40 that repeat the last two vertices, ADC on both (CNT tags). */
static void test_long_strip(void)
{
    VifVtx v[60];
    bool adc[60] = { 1, 1 };
    const bool restart[22] = { 1, 1 };
    make_strip(v, 60, 1);
    VifBuild b;
    vif_begin(&b);
    vif_batch(&b, v, adc, 40, 0);
    vif_cnt(&b);
    vif_batch(&b, v + 38, restart, 22, 0);
    vif_end(&b, 0);
    NwVifMesh m = { 0 };
    CHECK(decode(&m, &b));
    CHECK(m.nbatches == 2 && m.nverts == 62 && m.ntris == 58);
    bool same = m.ntris == 58;
    for (uint32_t t = 0; same && t < 58; t++) {
        uint32_t i = t + 2, want[3] = { i - 2, i & 1 ? i : i - 1, i & 1 ? i - 1 : i };
        for (int k = 0; k < 3; k++) {
            uint32_t got = m.tris[3 * t + k];
            same = same && (got < 40 ? got : got - 40 + 38) == want[k];
        }
    }
    CHECK(same);
    CHECK(same_vertices(&m, 40, v + 38, restart, 22, false, false));
    nw_vif_free(&m);
    vif_free(&b);
}

static void test_packed(void)
{
    const float span[3] = { 4096.0f, 4096.0f, 4096.0f }, mid[3] = { 1.0f, 2.0f, 3.0f };
    VifVtx v[5];
    const bool adc[5] = { 1, 1, 0, 0, 0 };
    make_strip(v, 5, 2);
    for (unsigned flags = 0; flags <= VIF_UV_ROW; flags += VIF_UV_ROW) {
        VifBuild b;
        vif_begin(&b);
        vif_packed(&b, span, mid);
        vif_batch(&b, v, adc, 5, VIF_FAST_UV | flags);
        vif_batch(&b, v, adc, 5, flags);
        vif_end(&b, 0);
        NwVifMesh m = { 0 };
        CHECK(decode(&m, &b));
        CHECK(m.nbatches == 2 && m.nverts == 10 && m.ntris == 6 && m.uvrow == (flags != 0));
        CHECK(same_vertices(&m, 0, v, adc, 5, true, true));
        CHECK(same_vertices(&m, 5, v, adc, 5, true, false));
        nw_vif_free(&m);
        vif_free(&b);
    }
    VifBuild b;
    vif_begin(&b);
    vif_batch(&b, v, adc, 5, VIF_UV_ROW);
    vif_batch(&b, v, adc, 5, 0);
    vif_end(&b, 0);
    NwVifMesh m = { 0 };
    CHECK_FAILS(decode(&m, &b), "texcoords under STMOD 0 and 1 in one geom");
    nw_vif_free(&m);
    vif_free(&b);
}

static void test_chain(void)
{
    VifVtx v[6];
    const bool adc[6] = { 1, 1, 0, 0, 0, 0 };
    make_strip(v, 6, 3);
    VifBuild b;
    vif_begin(&b);
    vif_batch(&b, v, adc, 6, 0);
    vif_batch(&b, v, adc, 6, VIF_SPLIT_NEXT);
    vif_batch(&b, v, adc, 6, VIF_FAST_UV);
    vif_end(&b, 400);
    NwVifMesh m = { 0 };
    CHECK(decode(&m, &b));
    CHECK(m.nbatches == 3 && m.nverts == 18 && m.ntris == 12);
    CHECK(same_vertices(&m, 6, v, adc, 6, false, false));
    CHECK(same_vertices(&m, 12, v, adc, 6, false, true));
    nw_vif_free(&m);
    vif_free(&b);

    /* Face-on sprites kick 0x304 and are no triangle batch. */
    vif_begin(&b);
    vif_faceon(&b, 5);
    vif_end(&b, 0);
    CHECK(decode(&m, &b));
    CHECK(m.nbatches == 0 && m.nverts == 0);
    nw_vif_free(&m);
    vif_free(&b);
}

static void test_sprites(void)
{
    VifBuild b;
    NwVifSprites s;
    vif_begin(&b);
    vif_faceon(&b, 5);
    vif_faceon(&b, 2);
    vif_end(&b, 64);
    CHECK(nw_vif_sprites(&s, b.buf, b.len) && s.count == 7 && !s.facey);
    CHECK(s.count == 7 && s.sprites[1].pos[0] == 3.0f && s.sprites[1].pos[2] == 5.0f && s.sprites[6].pos[1] == 4.0f);
    CHECK(s.count == 7 && s.sprites[4].size[1] == -1.0f && s.sprites[6].col[0] == 0x80 && s.sprites[6].col[3] == 0x40);
    nw_vif_sprites_free(&s);
    vif_free(&b);

    vif_begin(&b);
    vif_facey(&b, 3);
    vif_end(&b, 0);
    CHECK(nw_vif_sprites(&s, b.buf, b.len) && s.count == 3 && s.facey);
    CHECK(s.count == 3 && s.sprites[2].pos[2] == 6.0f && s.sprites[2].size[1] == 1.5f && s.sprites[0].col[0] == 0x30);
    nw_vif_sprites_free(&s);
    vif_free(&b);

    vif_begin(&b);
    vif_faceon(&b, 1);
    vif_facey(&b, 1);
    vif_end(&b, 0);
    CHECK_FAILS(nw_vif_sprites(&s, b.buf, b.len), "faceon and facey batches in one geom");
    CHECK(s.count == 0 && s.sprites == NULL);
    vif_free(&b);
    VifVtx v[4];
    const bool adc[4] = { 1, 1, 0, 0 };
    make_strip(v, 4, 4);
    vif_begin(&b);
    vif_batch(&b, v, adc, 4, 0);
    vif_end(&b, 0);
    CHECK_FAILS(nw_vif_sprites(&s, b.buf, b.len), "outside a batch");
    vif_free(&b);
}

static void test_errors(void)
{
    VifVtx v[4];
    const bool adc[4] = { 1, 1, 0, 0 };
    make_strip(v, 4, 4);
    NwVifMesh m = { 0 };
    VifBuild b;

    vif_begin(&b);
    vif_batch(&b, v, adc, 4, 0);
    vif_end(&b, 0);
    CHECK(decode(&m, &b));
    CHECK_FAILS(nw_vif_decode(&m, b.buf, b.len - 16), "runs past the geom");
    CHECK_FAILS(nw_vif_decode(&m, b.buf, 8), "outside the geom");
    b.buf[3] = 0x30; /* REF */
    CHECK_FAILS(decode(&m, &b), "DMA tag id 3");
    CHECK(m.nverts == 4 && m.ntris == 2);
    vif_free(&b);

    vif_begin(&b);
    vif_batch(&b, v, adc, 4, 0);
    vif_next(&b, 0x30);
    vif_end(&b, 0);
    uint32_t addr = (uint32_t)b.len + 0x100;
    memcpy(b.buf + 4, &addr, 4);
    CHECK_FAILS(decode(&m, &b), "outside the geom");
    addr = 0;
    memcpy(b.buf + 4, &addr, 4);
    CHECK_FAILS(decode(&m, &b), "sends more than the geom holds");
    vif_free(&b);

    vif_begin(&b);
    vif_batch(&b, v, adc, 4, VIF_BAD_NLOOP);
    vif_end(&b, 0);
    CHECK_FAILS(decode(&m, &b), "NLOOP 5");
    vif_free(&b);

    vif_begin(&b);
    vif_batch(&b, v, adc, 4, VIF_NO_COLOUR);
    vif_end(&b, 0);
    CHECK_FAILS(decode(&m, &b), "without colours");
    vif_free(&b);

    vif_begin(&b);
    vif_word(&b, 0x50000001); /* DIRECT */
    vif_end(&b, 0);
    CHECK_FAILS(decode(&m, &b), "VIF command 0x50");
    vif_free(&b);

    vif_begin(&b);
    vif_word(&b, 0x6C048003); /* 4 positions, no data */
    vif_end(&b, 0);
    CHECK_FAILS(decode(&m, &b), "runs past the end");
    vif_free(&b);

    vif_begin(&b);
    vif_word(&b, 0x01000103);
    vif_word(&b, 0x05000001);
    vif_word(&b, 0x6D018003);
    vif_word(&b, 0);
    vif_word(&b, 0x80010000);
    vif_end(&b, 0);
    CHECK_FAILS(decode(&m, &b), "V4-16 positions without");
    vif_free(&b);

    vif_begin(&b);
    vif_word(&b, 0x01000103);
    vif_word(&b, 0x6C018003);
    for (int i = 0; i < 4; i++) {
        vif_word(&b, 0);
    }
    vif_end(&b, 0);
    CHECK_FAILS(decode(&m, &b), "not kicked");
    vif_free(&b);

    CHECK(m.nverts == 4 && m.nbatches == 1);
    nw_vif_free(&m);

    /* A .ghg geom's chain carries no size: the image after it bounds it. */
    vif_begin(&b);
    vif_batch(&b, v, adc, 4, 0);
    vif_end(&b, 0);
    uint8_t *image = malloc(b.len + 0x200);
    memcpy(image, b.buf, b.len);
    memset(image + b.len, 0xCD, 0x200);
    CHECK(nw_vif_decode(&m, image, b.len + 0x200) && m.nverts == 4 && m.ntris == 2);
    nw_vif_free(&m);
    free(image);
    vif_free(&b);
}

static VifSkinVtx skin_vtx(float x, uint8_t nw, const float *w, const uint8_t *slot, bool adc)
{
    VifSkinVtx v = { .pos = { x, x * 2.0f, -x }, .nrm = { 0.5f, 0.25f, -1.0f }, .uv = { x * 0.5f, 1.0f - x },
                     .nw = nw, .adc = adc };
    memcpy(v.w, w, nw * sizeof(float));
    memcpy(v.slot, slot, nw);
    return v;
}

static VifSkinVtx skin_dupe(uint8_t of, bool adc)
{
    VifSkinVtx v = { .dupe = (uint8_t)(of + 1), .adc = adc };
    return v;
}

static bool skin_list(NwVifSkin *s, VifBuild *out)
{
    return nw_vif_skin(s, out->buf, out->len);
}

/* A point's fields as the VU reads them: the tags in the low bytes stay, weights round down to 1/32768. */
static void test_skin(void)
{
    static const uint8_t joints[3] = { 5, 9, 2 }, s012[3] = { 0, 1, 2 }, s021[3] = { 0, 2, 1 };
    static const float one[1] = { 1.0f }, two[2] = { 0.25f, 0.75f }, three[3] = { 0.5f, 0.25f, 0.25f };
    static const float third[3] = { 0.3f, 0.3f, 0.4f };
    VifSkinVtx v[5] = {
        skin_vtx(1.0f, 1, one, s012, true),   skin_vtx(2.0f, 2, two, s012, true), skin_vtx(3.0f, 3, three, s021, false),
        skin_dupe(0, false), skin_vtx(4.0f, 3, third, s012, false),
    };
    v[4].slot[0] = 2;
    v[4].slot[2] = 0;
    VifSkin sk;
    VifBuild b;
    NwVifSkin s;
    vif_skin_begin(&sk);
    vif_skin_group(&sk, joints, 3);
    vif_skin_batch(&sk, v, 5, NULL, 0, 0);
    vif_skin_end(&sk, &b);
    CHECK(skin_list(&s, &b));
    CHECK(s.nverts == 4 && s.ndupes == 1 && s.nbatches == 1 && s.ntris == 3 && s.ndeltas == 0 && s.maxjoint == 9);
    if (s.nverts == 4 && s.ntris == 3) {
        static const uint32_t tris[9] = { 0, 1, 2, 1, 0, 2, 2, 0, 3 };
        CHECK(memcmp(s.tris, tris, sizeof(tris)) == 0);
        const NwVifSkinVertex *a = &s.verts[0], *c = &s.verts[2], *d = &s.verts[3];
        CHECK(a->pos[0] == 1.0f && a->pos[1] == 2.0f && a->pos[2] == -1.0f && fbits(a->uv[1]) == 1);
        CHECK(fbits(a->nrm[0]) == (fbits(0.5f) & ~0xFFu) && fbits(a->nrm[2]) == (fbits(-1.0f) & ~0xFFu) + 1);
        CHECK(fbits(a->uv[0]) == (fbits(0.5f) & ~0xFFu) && a->nrmjoint == 5);
        CHECK(a->weight[0] == 32768 && a->joint[0] == 5 && a->weight[1] == 0);
        CHECK(s.verts[1].weight[0] == 8192 && s.verts[1].weight[1] == 24576 && s.verts[1].joint[1] == 9);
        CHECK(s.verts[1].nrmjoint == 9 && fbits(s.verts[1].uv[0]) == (fbits(1.0f) & ~0xFFu) + 1);
        CHECK(c->joint[0] == 5 && c->joint[1] == 2 && c->joint[2] == 9 && c->weight[2] == 8192 && c->nrmjoint == 5);
        CHECK(d->weight[0] == 9830 && d->joint[0] == 2 && d->joint[2] == 5 && d->weight[2] == 13107);
        CHECK(d->nrmjoint == 5 && d->ndeltas == 0);
    }
    nw_vif_skin_free(&s);
    vif_free(&b);

    static const float w8[8] = { 0.125f, 0.125f, 0.125f, 0.125f, 0.0625f, 0.1875f, 0.25f, 0.0f };
    static const uint8_t s8[8] = { 0, 1, 2, 3, 4, 5, 6, 7 }, j8[8] = { 10, 11, 12, 13, 14, 15, 16, 17 };
    VifSkinVtx w[4];
    for (int i = 0; i < 4; i++) {
        w[i] = skin_vtx((float)i, (uint8_t)(5 + i), w8, s8, true);
    }
    vif_skin_begin(&sk);
    vif_skin_group(&sk, j8, 8);
    vif_skin_batch(&sk, w, 4, NULL, 0, 0);
    vif_skin_end(&sk, &b);
    CHECK(skin_list(&s, &b));
    CHECK(s.nverts == 4 && s.ntris == 0 && s.maxjoint == 17);
    if (s.nverts == 4) {
        CHECK(s.verts[0].weight[4] == 2048 && s.verts[0].joint[4] == 14 && s.verts[0].weight[5] == 0);
        CHECK(s.verts[2].weight[6] == 8192 && s.verts[2].joint[6] == 16 && s.verts[2].nrmjoint == 16);
        CHECK(s.verts[3].weight[7] == 0 && s.verts[3].joint[7] == 17 && s.verts[1].weight[5] == 6144);
    }
    nw_vif_skin_free(&s);
    vif_free(&b);

    /* The second group's first batch continues at MSCNT; a blended batch is kicked at 0x302. */
    static const uint8_t ja[2] = { 1, 2 }, jb[2] = { 7, 3 };
    const VifSkinDelta deltas[3] = {
        { 2, 1, { 1.0f, 2.0f, 3.0f } }, { 2, 0, { 4.0f, 5.0f, 6.0f } }, { 5, 1, { -1.0f, 0.0f, 0.5f } },
    };
    VifSkinVtx g[3] = { skin_vtx(1.0f, 1, one, s012, true), skin_vtx(2.0f, 2, two, s012, true),
                        skin_vtx(3.0f, 1, one, s012, false) };
    vif_skin_begin(&sk);
    vif_skin_group(&sk, ja, 2);
    vif_skin_batch(&sk, g, 3, NULL, 0, 0);
    vif_skin_group(&sk, jb, 2);
    vif_skin_batch(&sk, g, 3, NULL, 0, 0);
    vif_skin_batch(&sk, g, 3, deltas, 3, 0);
    vif_skin_batch(&sk, g, 3, NULL, 0, 0);
    vif_skin_end(&sk, &b);
    CHECK(skin_list(&s, &b));
    CHECK(s.nverts == 12 && s.ntris == 4 && s.nbatches == 4 && s.ndeltas == 3);
    if (s.nverts == 12 && s.ndeltas == 3) {
        CHECK(s.verts[0].joint[0] == 1 && s.verts[3].joint[0] == 7 && s.verts[4].joint[1] == 3);
        const NwVifSkinVertex *v0 = &s.verts[6], *v1 = &s.verts[7];
        CHECK(v0->ndeltas == 1 && v1->ndeltas == 2 && s.verts[8].ndeltas == 0 && s.verts[9].ndeltas == 0);
        CHECK(s.deltas[v0->delta][0] == 4.0f && s.deltas[v0->delta][3] == 2.0f);
        CHECK(s.deltas[v1->delta][2] == 3.0f && s.deltas[v1->delta][3] == 2.0f);
        CHECK(s.deltas[v1->delta + 1][0] == -1.0f && s.deltas[v1->delta + 1][3] == 5.0f);
    }
    nw_vif_skin_free(&s);
    vif_free(&b);
}

static void test_skin_errors(void)
{
    static const uint8_t joints[2] = { 4, 6 }, s01[2] = { 0, 1 }, s03[2] = { 0, 3 };
    static const float two[2] = { 0.5f, 0.5f };
    VifSkinVtx v[3] = { skin_vtx(1.0f, 2, two, s01, true), skin_vtx(2.0f, 2, two, s01, true),
                        skin_vtx(3.0f, 2, two, s01, false) };
    const VifSkinDelta delta = { 0, 1, { 1.0f, 1.0f, 1.0f } };
    struct {
        unsigned flags;
        int bad; /* 1 forward dupe, 2 slot 3, 3 delta at a dupe, 4 delta past the batch, 5 blended MSCNT */
        const char *text;
    } cases[] = {
        { VIF_BAD_NLOOP, 0, "NLOOP 4" },
        { VIF_SKIN_MSCNT, 0, "first skin batch continued by MSCNT" },
        { VIF_SKIN_COLOUR, 0, "skin STCYCL 5,3" },
        { 0, 1, "vertex 1 a dupe of vertex 1" },
        { 0, 2, "slot 3 of 2" },
        { 0, 3, "skinmod delta for vertex 1" },
        { 0, 4, "skinmod delta for vertex 7" },
        { 0, 5, "blended skin batch continued by MSCNT" },
    };
    NwVifSkin s;
    VifSkin sk;
    VifBuild b;
    for (size_t i = 0; i < SDL_arraysize(cases); i++) {
        VifSkinVtx bad[3] = { v[0], v[1], v[2] };
        VifSkinDelta d = delta;
        if (cases[i].bad == 1) {
            bad[1] = skin_dupe(1, true);
        } else if (cases[i].bad == 2) {
            memcpy(bad[2].slot, s03, 2);
        } else if (cases[i].bad == 3) {
            bad[1] = skin_dupe(0, true);
        } else if (cases[i].bad == 4) {
            d.vertex = 7;
        }
        vif_skin_begin(&sk);
        vif_skin_group(&sk, joints, 2);
        if (cases[i].bad == 5) {
            vif_skin_batch(&sk, v, 3, NULL, 0, 0);
        }
        vif_skin_batch(&sk, bad, 3, cases[i].bad >= 3 ? &d : NULL, cases[i].bad >= 3 ? 1 : 0,
                       cases[i].bad == 5 ? VIF_SKIN_MSCNT : cases[i].flags);
        vif_skin_end(&sk, &b);
        CHECK_FAILS(skin_list(&s, &b), cases[i].text);
        CHECK(s.nverts == 0 && s.verts == NULL);
        vif_free(&b);
    }

    vif_skin_begin(&sk);
    vif_skin_group(&sk, joints, 2);
    vif_skin_batch(&sk, v, 3, NULL, 0, 0);
    vif_skin_end(&sk, &b);
    CHECK(skin_list(&s, &b));
    nw_vif_skin_free(&s);
    CHECK_FAILS(nw_vif_skin(&s, b.buf, 0x30), "outside the geom"); /* CNT and 2 REFs: the CALL is cut */
    uint32_t addr;
    memcpy(&addr, b.buf + 0x34, 4);
    b.buf[addr + 3] = 0x10; /* the CALLed block's RET as CNT */
    CHECK_FAILS(skin_list(&s, &b), "reaches no RET block");
    b.buf[addr + 3] = 0x60;
    b.buf[0x23] = 0x20; /* a REF as NEXT */
    CHECK_FAILS(skin_list(&s, &b), "skin DMA tag id 2");
    b.buf[0x23] = 0x30;
    b.buf[0x2C] = 0x1A; /* the second REF to slot 2 */
    CHECK_FAILS(skin_list(&s, &b), "skin matrix tag at 0x20");
    vif_free(&b);
}

static void test_gsc(void)
{
    GscBuild b;
    GscScene s;
    gsc_build_scene(&b, &s);
    NwGsc g;
    CHECK(nw_gsc_open(&g, b.buf, b.len));
    CHECK(g.nchunks == 12 && g.unknown == 1 && !g.truncated);
    CHECK(g.nmtls == 3 && g.ninsts == 3 && g.nobjects == 2 && g.nblobs == 4);
    if (g.nobjects == 2 && g.nblobs == 4) {
        CHECK(g.objects[0].first == 0 && g.objects[0].count == 2);
        CHECK(g.objects[1].first == 2 && g.objects[1].count == 2);
        const uint32_t mtl[4] = { 0, 2, 1, 0 };
        for (int i = 0; i < 4; i++) {
            CHECK(g.blobs[i].offset == s.blob[i] && g.blobs[i].size == s.blob_size[i] && g.blobs[i].mtl == mtl[i]);
            CHECK(g.blobs[i].ot == (i == 2) && g.blobs[i].faceon == (i == 3));
        }
        for (int i = 0; i < 2; i++) {
            NwVifMesh m = { 0 };
            CHECK(nw_vif_decode(&m, g.data + g.blobs[i].offset, g.blobs[i].size));
            CHECK(m.nbatches == s.batches[i] && m.nverts == s.verts[i] && m.ntris == s.tris[i]);
            nw_vif_free(&m);
        }
    }
    const int16_t k = -90;
    const float scroll[4] = { 0.5f, 0.25f, 2.0f, -1.0f };
    memcpy(b.buf + g.mtls + 0x1AC, &k, 2);
    b.buf[g.mtls + 0x1AE] = 1;
    b.buf[g.mtls + 0x1AF] = 0x12;
    memcpy(b.buf + g.mtls + 0x1B0, scroll, sizeof(scroll));
    NwGscMtl m = nw_gsc_mtl(&g, 0);
    CHECK(NW_GSC_ATTRIB_LIGHTING(m.attrib) == 2 && !NW_GSC_ATTRIB_OT(m.attrib) && m.tid == -1);
    CHECK(m.k == -90 && m.l == 1 && m.umode == 2 && m.vmode == 1);
    CHECK(m.du == 0.5f && m.dv == 0.25f && m.su == 2.0f && m.sv == -1.0f);
    CHECK(m.diffuse[1] == 0.5f && m.alpha == 1.0f);
    m = nw_gsc_mtl(&g, 1);
    CHECK(NW_GSC_ATTRIB_COLOUR(m.attrib) == 1 && NW_GSC_ATTRIB_OT(m.attrib));
    NwGscInst inst = nw_gsc_inst(&g, 2);
    CHECK(inst.objid == 0 && inst.flags == 1 && inst.mtx[12] == 20.0f && inst.mtx[15] == 1.0f);
    nw_gsc_close(&g);

    CHECK(nw_gsc_open(&g, b.buf, b.len - 2));
    CHECK(g.truncated && g.nchunks == 11 && g.unknown == 0 && g.nobjects == 2);
    nw_gsc_close(&g);

    uint8_t *bad = malloc(b.len);
    struct {
        size_t at;
        uint32_t value;
        const char *error;
    } cases[] = {
        { 0, 0x3032554F, "not an NU20 scene" },
        { 8, 5, "scene version 5" },
        { 20, 4, "of 4 bytes" },
        { s.geom0_mtl, 9, "material 9 of 3" },
        { s.sub0_type, 2, "type 2" },
        { s.geom0_size, 0x18, "geom of 24 bytes" },
    };
    for (size_t i = 0; i < SDL_arraysize(cases); i++) {
        memcpy(bad, b.buf, b.len);
        memcpy(bad + cases[i].at, &cases[i].value, 4);
        CHECK_FAILS(nw_gsc_open(&g, bad, b.len), cases[i].error);
    }
    free(bad);
    gsc_free(&b);
}

/* The PSMT4 texture tests/test_gsc_hash.py pins: index (x + 2y) & 15, CLUT entry c = 16c, 255 - 16c, 3c, 8c. */
static void make_psmt4(uint8_t clut[16][4], uint8_t packed[32])
{
    for (int c = 0; c < 16; c++) {
        const uint8_t rgba[4] = { (uint8_t)(c * 16), (uint8_t)(255 - c * 16), (uint8_t)(c * 3), (uint8_t)(c * 8) };
        memcpy(clut[c], rgba, 4);
    }
    memset(packed, 0, 32);
    for (int i = 0; i < 64; i++) {
        packed[i >> 1] |= (uint8_t)((((i & 7) + 2 * (i >> 3)) & 15) << (i & 1) * 4);
    }
}

/* ps2_texture.py's _unswizzle8: where PSMT8 pixel (x, y) of a w-wide texture sits in its PSMCT32 upload. */
static size_t swizzle8(uint32_t x, uint32_t y, uint32_t w)
{
    size_t block = (size_t)(y & ~15u) * w + (x & ~15u) * 2;
    uint32_t swap = (((y + 2) >> 2) & 1) * 4, py = (((y & ~3u) >> 1) + (y & 1)) & 7;
    return block + (size_t)py * w * 2 + ((x + swap) & 7) * 4 + ((y >> 1) & 1) + ((x >> 2) & 2);
}

static void test_texture(void)
{
    GscBuild b = { 0 };
    uint8_t clut16[16][4], packed[32];
    make_psmt4(clut16, packed);
    size_t up = gsc_texture(&b, 4, 8, 8, clut16, packed, 8, 8, sizeof(packed), 2, 2, 1);
    NwTex t;
    bool ok = nw_tex_decode(&t, b.buf, b.len);
    CHECK(ok && t.version == 1 && t.type == 4 && t.tcc && t.ncolours == 16 && t.nlevels == 1);
    if (ok) {
        bool same = t.levels[0].width == 8 && t.levels[0].height == 8;
        for (int i = 0; i < 64 && same; i++) {
            same = t.levels[0].texels[i] == (((i & 7) + 2 * (i >> 3)) & 15);
        }
        CHECK(same && memcmp(t.clut, clut16, sizeof(clut16)) == 0);
        char line[256];
        nw_gsc_tex_line(0, &t, line, sizeof(line));
        CHECK(strcmp(line, "TEX 0 8x8 type=4 version=1 levels=1 "
                           "rgba=8d5cce5284f06b924fa01c1b8a0b335b49fe6182c3533c2dfb9f08d921632092") == 0);
        nw_tex_free(&t);
    }
    uint8_t *bad = malloc(b.len);
    struct {
        size_t at;
        uint32_t value, bytes;
        const char *error;
    } cases[] = {
        { 2, 2, 2, "header version 2" },
        { 12, 1, 1, "type 1" },
        { 12, 2, 1, "type 2 with psm 0x14" },
        { 13, 0x13, 1, "type 4 with psm 0x13" },
        { 15, 0x80, 1, "8x8 with 0 levels" },
        { 28, 1, 4, "CLUT psm 0x1" },
        { up, 0x30000006, 4, "DMA tag id 3" },
        { up, 0x60000006, 4, "has 16 of 32 bytes" },
        { up + 48, 16, 4, "TRXREG 16x8 for an upload of 8x8" },
    };
    for (size_t i = 0; i < SDL_arraysize(cases); i++) {
        memcpy(bad, b.buf, b.len);
        memcpy(bad + cases[i].at, &cases[i].value, cases[i].bytes);
        CHECK_FAILS(nw_tex_decode(&t, bad, b.len), cases[i].error);
    }
    CHECK_FAILS(nw_tex_decode(&t, b.buf, 10), "record of 10 bytes");
    CHECK_FAILS(nw_tex_decode(&t, b.buf, b.len - 16), "level 0 of");
    free(bad);
    gsc_free(&b);

    /* PSMT8: CLUT entry i stored at CSM1 position i ^ (bits 3 and 4), the texels linear (5) or as PSMCT32 (7). */
    static uint8_t clut[256][4], idx[32 * 32], swz[32 * 32];
    for (int i = 0; i < 256; i++) {
        int csm1 = (i & 0xE7) | ((i & 0x10) >> 1) | ((i & 0x08) << 1);
        const uint8_t rgba[4] = { (uint8_t)i, (uint8_t)(255 - i), (uint8_t)(i ^ 0x55), (uint8_t)(i >> 1) };
        memcpy(clut[csm1], rgba, 4);
    }
    for (uint32_t y = 0; y < 32; y++) {
        for (uint32_t x = 0; x < 32; x++) {
            idx[y * 32 + x] = (uint8_t)(x * 7 + y * 13);
            swz[swizzle8(x, y, 32)] = idx[y * 32 + x];
        }
    }
    for (uint32_t type = 5; type <= 7; type += 2) {
        gsc_texture(&b, type, 32, 32, clut, type == 5 ? idx : swz, type == 5 ? 32 : 16, type == 5 ? 32 : 16,
                    sizeof(idx), 2, 1, type == 5 ? 2 : 1);
        ok = nw_tex_decode(&t, b.buf, b.len);
        CHECK(ok && t.type == type && t.ncolours == 256 && t.nlevels == (type == 5 ? 2 : 1));
        if (ok) {
            bool same = memcmp(t.levels[0].texels, idx, sizeof(idx)) == 0;
            if (type == 5) {
                same = same && t.levels[1].width == 16 && t.levels[1].height == 16 &&
                       memcmp(t.levels[1].texels, idx, 256) == 0;
            }
            for (int i = 0; i < 256 && same; i++) {
                same = t.clut[i][0] == i && t.clut[i][1] == 255 - i && t.clut[i][2] == (i ^ 0x55);
            }
            CHECK(same);
            nw_tex_free(&t);
        }
        gsc_free(&b);
    }
    /* Type 6 (PSMT4 as PSMCT32 at a quarter of the height) only needs its buffer widths. */
    gsc_texture(&b, 6, 32, 32, clut16, idx, 16, 8, 16 * 8 * 4, 2, 1, 1);
    ok = nw_tex_decode(&t, b.buf, b.len);
    CHECK(ok && t.levels[0].width == 32 && t.levels[0].height == 32);
    nw_tex_free(&t);
    gsc_free(&b);
    gsc_texture(&b, 6, 32, 32, clut16, idx, 16, 8, 16 * 8 * 4, 1, 1, 1);
    CHECK_FAILS(nw_tex_decode(&t, b.buf, b.len), "buffer widths 1/1");
    gsc_free(&b);

    /* Direct colours: PSMCT24 gets the alpha 0x80 (TCC is off), PSMCT32 keeps its own. */
    for (uint32_t type = 2; type <= 3; type++) {
        gsc_texture(&b, type, 16, 16, NULL, idx, 16, 16, 16 * 16 * (type == 2 ? 3 : 4), 1, 1, 1);
        ok = nw_tex_decode(&t, b.buf, b.len);
        CHECK(ok && t.type == type && t.ncolours == 0 && t.tcc == (type == 3));
        if (ok) {
            const uint8_t *px = t.levels[0].texels + 5 * 4, *src = idx + 5 * (type == 2 ? 3 : 4);
            uint8_t rgba[16 * 4];
            nw_tex_rgba(&t, 0, rgba);
            CHECK(memcmp(px, src, 3) == 0 && px[3] == (type == 2 ? 0x80 : src[3]));
            CHECK(rgba[5 * 4 + 3] == (type == 2 ? 255 : SDL_min(255, src[3] * 2)));
            nw_tex_free(&t);
        }
        gsc_free(&b);
    }

    const uint32_t head[3] = { 16, 16, 0 };
    const uint8_t formats[4] = { 5, 0x13, 1, 1 };
    gsc_bytes(&b, head, sizeof(head));
    gsc_bytes(&b, formats, 4);
    size_t pal = b.len;
    const uint32_t palhead[4] = { 0, 0x2000, 1, 0 };
    gsc_bytes(&b, palhead, sizeof(palhead));
    gsc_upload(&b, 16, 16, clut, sizeof(clut));
    gsc_put32(&b, pal, (uint32_t)(b.len - pal));
    size_t mip = b.len;
    const uint32_t level[24] = {
        0, 256, 2, 0, 0x10000004, 0, 0, 0x50000004, 0x8003, 0x10000000, 0xE, 0,
        0, 0, 0x51, 0, 16, 16, 0x52, 0, 0, 0, 0x53, 0,
    };
    const uint32_t image[8] = { 0x60000011, 0, 0, 0x50000011, 0x8010, 0x08000000, 0, 0 };
    gsc_bytes(&b, level, sizeof(level));
    gsc_bytes(&b, image, sizeof(image));
    gsc_bytes(&b, idx, 256);
    gsc_put32(&b, mip, (uint32_t)(b.len - mip));
    ok = nw_tex_decode(&t, b.buf, b.len);
    CHECK(ok && t.version == 0 && t.type == 5 && t.levels[0].width == 16 && t.tcc);
    if (ok) {
        CHECK(memcmp(t.levels[0].texels, idx, 256) == 0 && t.clut[255][0] == 255);
        nw_tex_free(&t);
    }
    gsc_free(&b);
}

/* ReadTextureSet's walk: a skip of 0 reads two more ints. */
static void test_texset(const char *scratch)
{
    GscBuild b = { 0 };
    uint8_t clut16[16][4], packed[32];
    make_psmt4(clut16, packed);
    gsc_bytes(&b, "NU20", 4);
    gsc_u32(&b, 0);
    gsc_u32(&b, 6);
    gsc_u32(&b, 0);
    gsc_open(&b, "TST0");
    gsc_u32(&b, 2);
    gsc_u32(&b, 0);
    size_t at[2], size[2], count = b.blk + 8;
    for (int i = 0; i < 2; i++) {
        size[i] = b.len;
        gsc_u32(&b, 0);
        gsc_u32(&b, i ? 24 : 0);
        gsc_zero(&b, i ? 24 : 8);
        at[i] = b.len;
        gsc_texture(&b, 4, 8, 8, clut16, packed, 8, 8, sizeof(packed), 2, 2, 1);
        gsc_put32(&b, size[i], (uint32_t)(b.len - at[i]));
    }
    gsc_close(&b);
    gsc_put32(&b, 4, (uint32_t)-(int32_t)b.len);

    NwGsc g;
    NwTex t;
    CHECK(nw_gsc_open(&g, b.buf, b.len));
    CHECK(g.ntextures == 2 && g.textures[0].offset == at[0] && g.textures[1].offset == at[1]);
    CHECK(nw_gsc_texture(&g, 1, &t) && t.levels[0].width == 8);
    nw_tex_free(&t);
    CHECK_FAILS(nw_gsc_texture(&g, 2, &t), "texture 2 of 2");
    char *path = NULL;
    SDL_asprintf(&path, "%s/texset.txt", scratch);
    FILE *out = fopen(path, "w+");
    NwGscTotal total = { 0 };
    CHECK(out && nw_gsc_report(&g, "TEX.GSC", out, &total));
    if (out) {
        nw_gsc_report_total(&total, out);
        char text[1024];
        rewind(out);
        text[fread(text, 1, sizeof(text) - 1, out)] = 0;
        CHECK(strstr(text, "TEX 1 8x8 type=4 version=1 levels=1 rgba=8d5cce5284f06b92") &&
              strstr(text, "\nGSC TEX.GSC chunks=1 unknown=0 truncated=0 objects=0 batches=0 verts=0 tris=0 "
                           "textures=2\n"
                           "TOTAL files=1 failed=0 unknown=0 truncated=0 objects=0 batches=0 verts=0 tris=0 "
                           "textures=2\n"));
        fclose(out);
    }
    SDL_RemovePath(path);
    SDL_free(path);
    nw_gsc_close(&g);

    gsc_put32(&b, count, 99);
    CHECK_FAILS(nw_gsc_open(&g, b.buf, b.len), "TST0 of");
    gsc_put32(&b, count, 2);
    gsc_put32(&b, size[1], 0x10000);
    CHECK_FAILS(nw_gsc_open(&g, b.buf, b.len), "TST0 runs past its block");
    gsc_free(&b);
}

static void test_mtl(void)
{
    static const struct {
        uint8_t mmag, mmin;
    } filters[4] = { { 0, 0 }, { 1, 1 }, { 1, 5 }, { 0, 0 } };
    for (uint32_t filter = 0; filter < 4; filter++) {
        const uint32_t attrib[2] = { filter << 4 | 1u << 8 | 2u << 10, 0 };
        NwMtlState s = nw_mtl_state(attrib, -90, 1, 4);
        CHECK(s.mmag == filters[filter].mmag && s.mmin == filters[filter].mmin);
        CHECK(s.mxl == (filter == 2 ? 3 : 0) && s.k == -90 && s.l == 1 && s.wms == 1 && s.wmt == 0);
        CHECK(nw_mtl_state(attrib, 0, 0, 0).mxl == 0);
    }
}

static void test_blend(void)
{
    static const uint8_t alpha[8] = { 0x44, 0x44, 0x48, 0x42, 0x49, 0x46, 0x89, 0x44 };
    for (uint32_t i = 0; i < 8; i++) {
        const uint32_t attrib[2] = { i, 0 };
        NwMtlState s = nw_mtl_state(attrib, 0, 0, 0);
        CHECK(s.abe == (i != 0) && s.alpha == alpha[i]);
    }
    static const struct {
        uint8_t alpha;
        NwMtlBlend blend;
    } cases[] = {
        { 0x44, { NW_BLEND_ADD, NW_BLEND_SRC_ALPHA, NW_BLEND_ONE_MINUS_SRC_ALPHA, false } },
        { 0x48, { NW_BLEND_ADD, NW_BLEND_SRC_ALPHA, NW_BLEND_ONE, false } },
        { 0x42, { NW_BLEND_REVERSE_SUBTRACT, NW_BLEND_SRC_ALPHA, NW_BLEND_ONE, false } },
        { 0x49, { NW_BLEND_ADD, NW_BLEND_DST_COLOUR, NW_BLEND_ONE, true } },
        { 0x46, { NW_BLEND_ADD, NW_BLEND_ZERO, NW_BLEND_ONE_MINUS_SRC_ALPHA, false } },
        { 0x89, { NW_BLEND_ADD, NW_BLEND_ZERO, NW_BLEND_SRC_ALPHA, false } },
        { 0x84, { NW_BLEND_SUBTRACT, NW_BLEND_SRC_ALPHA, NW_BLEND_SRC_ALPHA, false } }, /* (Cs - Cd) * As */
        { 0x54, { NW_BLEND_ADD, NW_BLEND_DST_ALPHA, NW_BLEND_ONE_MINUS_DST_ALPHA, false } }, /* (Cs - Cd) * Ad + Cd */
    };
    for (size_t i = 0; i < SDL_arraysize(cases); i++) {
        NwMtlBlend b;
        CHECK(nw_mtl_blend(cases[i].alpha, &b) && b.op == cases[i].blend.op && b.src == cases[i].blend.src &&
              b.dst == cases[i].blend.dst && b.as_colour == cases[i].blend.as_colour);
    }
    NwMtlBlend b;
    CHECK_FAILS(nw_mtl_blend(0x64, &b), "ALPHA 0x64");
    CHECK_FAILS(nw_mtl_blend(0x08, &b), "ALPHA 0x08 has no GL blend"); /* Cs * (1 + As) */
}

static void test_depth(void)
{
    static const struct {
        uint8_t ztst;
        bool zmsk;
    } modes[4] = { { 2, false }, { 2, true }, { 1, false }, { 1, true } };
    for (uint32_t zmode = 0; zmode < 4; zmode++) {
        const uint32_t attrib[2] = { zmode << 14, 0 };
        NwMtlState s = nw_mtl_state(attrib, 0, 0, 0);
        CHECK(s.ztst == modes[zmode].ztst && s.zmsk == modes[zmode].zmsk);
    }
}

static void test_atest(void)
{
    uint32_t attrib[2] = { 1u | 5u << 20 | 0x7Eu << 23, 3 };
    NwMtlState s = nw_mtl_state(attrib, 0, 0, 0);
    CHECK(s.ate && s.atst == 5 && s.aref == 0x7E && s.afail == 3);
    attrib[0] &= ~15u;
    CHECK(!nw_mtl_state(attrib, 0, 0, 0).ate);
    static const NwMtlPass second[4] = {
        { 0 }, { true, true, true, false }, { true, false, false, true }, { true, true, false, false },
    };
    NwMtlPass pass[2];
    for (uint8_t afail = 0; afail < 4; afail++) {
        s.afail = afail;
        s.zmsk = false;
        uint32_t n = nw_mtl_passes(&s, pass);
        CHECK(n == (afail ? 2u : 1u) && !pass[0].failed && pass[0].rgb && pass[0].alpha && pass[0].z);
        CHECK(n == 1 || memcmp(&pass[1], &second[afail], sizeof(pass[1])) == 0);
        s.zmsk = true;
        CHECK(nw_mtl_passes(&s, pass) == n && !pass[0].z && (n == 1 || !pass[1].z));
    }
    s.atst = 1; /* ALWAYS */
    CHECK(nw_mtl_passes(&s, pass) == 1);
    s.atst = 5;
    s.ate = false;
    CHECK(nw_mtl_passes(&s, pass) == 1);
}

static void test_package(void)
{
    static const struct {
        unsigned fx, lighting, colour;
        const char *package;
    } cases[] = {
        { 0, 0, 0, "vu_load_tri_mpg" },   { 0, 0, 1, "vu_load_tric_mpg" },  { 0, 1, 1, "vu_load_xformuv_mpg" },
        { 0, 2, 0, "vu_load_tricu_mpg" }, { 0, 3, 1, "vu_load_trica_mpg" }, { 1, 2, 0, "vu_load_xformuv_mpg" },
    };
    for (size_t i = 0; i < SDL_arraysize(cases); i++) {
        NwGscMtl m = { .attrib = { cases[i].fx << 6 | cases[i].lighting << 16 | cases[i].colour << 18, 1u << 3 },
                       .tid = -1 };
        CHECK(strcmp(nw_gsc_mtl_package(&m), cases[i].package) == 0);
    }
}

static void test_vu1init(void)
{
    /* A quarter turn about y, scaled by 2, then moved. */
    static const float local[16] = { 0, 0, -2, 0, 0, 2, 0, 0, 2, 0, 0, 0, 5, 6, 7, 1 };
    static const float screen[16] = { 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 2 };
    static const NwLights l = {
        { { 1.0f, 0.0f, 0.0f }, { 0.0f, 1.0f, 0.0f }, { 0.0f, 0.6f, 0.8f } },
        { { 0.5f, 0.25f, 1.0f }, { 1.0f, 1.0f, 1.0f }, { 0.0f, 0.0f, 0.0f } },
        { 0.1f, 0.2f, 0.3f },
        { { 0.0f } },
    };
    NwVuObject o;
    nw_vu1init(&o, local, screen);
    CHECK(o.lv[2] == -2.0f && o.lv[12] == 5.0f && o.lv[15] == 2.0f && o.lightdir[0][2] == 0.0f);
    nw_vu1init_lights(&o, local, &l);
    CHECK(o.lightdir[0][0] == 0.0f && o.lightdir[0][1] == 0.0f && o.lightdir[0][2] == 1.0f);
    CHECK(o.lightdir[1][1] == 1.0f && SDL_fabsf(o.lightdir[2][0] + 0.8f) < 1e-6f);
    CHECK(SDL_fabsf(o.lightdir[2][1] - 0.6f) < 1e-6f && o.lightdir[2][2] == 0.0f);
    CHECK(o.lightcol[0][1] == 0.25f && o.lightcol[0][3] == 0.0f && o.ambient[2] == 0.3f && o.lv[12] == 5.0f);

    /* A UV matrix taking world y to u and world x to v: the object's +z, world +x here, gives u 0 and v 1. */
    static const NwLights uv = { .uv = { { 0, 1, 0, 0 }, { 1, 0, 0, 0 }, { 0, 0, 1, 0 }, { 0.5f, 0.25f, 0, 1 } } };
    nw_vu1init_uv(&o, local, &uv);
    CHECK(o.uv[0][0] == 0.0f && o.uv[0][1] == 1.0f && o.uv[0][2] == 0.0f);
    CHECK(o.uv[1][0] == 0.0f && o.uv[1][1] == 0.0f && o.uv[1][2] == 1.0f);
    CHECK(o.uv[3][0] == 0.5f && o.uv[3][1] == 0.25f && o.lightdir[2][2] == 0.0f);

    /* A row scaled to 0 (the title logo growing in): the VU's 1/0 is MAX and 0 x MAX is 0. */
    static const float flat[16] = { 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1 };
    nw_vu1init_lights(&o, flat, &l);
    CHECK(o.lightdir[0][0] == 0.0f && o.lightdir[2][0] == 0.0f && o.lightdir[1][1] == 1.0f);
    CHECK(SDL_fabsf(o.lightdir[2][1] - 0.6f) < 1e-6f && SDL_fabsf(o.lightdir[2][2] - 0.8f) < 1e-6f);
}

static void test_packet(void)
{
    CHECK(nw_packet_take() == NULL);
    nw_packet_cmd(nw_packet_building())->op = NW_CMD_DRAW;
    nw_packet_publish(7);
    const NwPacket *p = nw_packet_take();
    CHECK(p && p->seq == 1 && p->vbcnt == 7 && p->ncmds == 1);
    CHECK(nw_packet_take() == p && nw_packet_building()->ncmds == 0);
    nw_packet_publish(8);
    nw_packet_publish(9);
    p = nw_packet_take();
    CHECK(p && p->seq == 3 && p->vbcnt == 9 && p->ncmds == 0);

    int mesh, tex;
    NwGpuJob *jobs = NULL;
    uint32_t cap = 0;
    nw_gpu_queue(NW_GPU_UPLOAD_MESH, &mesh);
    nw_gpu_queue(NW_GPU_FREE_TEX, &tex);
    CHECK(nw_gpu_take(3, &jobs, &cap) == 1 && jobs[0].op == NW_GPU_UPLOAD_MESH && jobs[0].obj == &mesh);
    nw_packet_publish(10);
    CHECK(nw_gpu_take(4, &jobs, &cap) == 0);
    nw_packet_publish(11);
    CHECK(nw_gpu_take(5, &jobs, &cap) == 1 && jobs[0].op == NW_GPU_FREE_TEX && jobs[0].obj == &tex);
    CHECK(nw_gpu_take(5, &jobs, &cap) == 0);
    SDL_free(jobs);
}

static void test_report(const char *scratch)
{
    GscBuild b;
    GscScene s;
    gsc_build_scene(&b, &s);
    char *path = NULL;
    SDL_asprintf(&path, "%s/report.txt", scratch);
    FILE *out = fopen(path, "w+");
    NwGsc g;
    NwGscTotal total = { 0 };
    CHECK(out && nw_gsc_open(&g, b.buf, b.len));
    if (out && g.data) {
        CHECK(nw_gsc_report(&g, "TEST.GSC", out, &total));
        nw_gsc_report_total(&total, out);
        nw_gsc_close(&g);
        char text[1024];
        rewind(out);
        text[fread(text, 1, sizeof(text) - 1, out)] = 0;
        static const char empty[] = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
        char obj1[200];
        SDL_snprintf(obj1, sizeof(obj1), "\nOBJ 1 batches=0 verts=0 tris=0 vtx=%s idx=%s\n", empty, empty);
        CHECK(strncmp(text, "OBJ 0 batches=3 verts=15 tris=9 vtx=", 36) == 0 && strstr(text, obj1));
        CHECK(strstr(text, "\nGSC TEST.GSC chunks=12 unknown=1 truncated=0 objects=2 batches=3 verts=15 tris=9 "
                           "textures=0\n"
                           "TOTAL files=1 failed=0 unknown=1 truncated=0 objects=2 batches=3 verts=15 tris=9 "
                           "textures=0\n"));
    }
    if (out) {
        fclose(out);
    }
    SDL_RemovePath(path);
    SDL_free(path);
    gsc_free(&b);
}

int main(int argc, char *argv[])
{
    if (argc != 2) {
        fprintf(stderr, "usage: test_scene <scratch dir>\n");
        return 2;
    }
    SDL_CreateDirectory(argv[1]);
    test_batch();
    test_strips();
    test_long_strip();
    test_packed();
    test_chain();
    test_errors();
    test_skin();
    test_skin_errors();
    test_sprites();
    test_gsc();
    test_package();
    test_texture();
    test_texset(argv[1]);
    test_mtl();
    test_blend();
    test_depth();
    test_atest();
    test_vu1init();
    test_packet();
    test_report(argv[1]);
    printf("%s\n", failures ? "FAILED" : "scene: all checks passed");
    return failures ? 1 : 0;
}
