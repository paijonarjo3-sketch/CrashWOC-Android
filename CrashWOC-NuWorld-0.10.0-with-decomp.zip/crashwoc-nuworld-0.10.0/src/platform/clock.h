/* Edges on absolute deadlines (t0 + k * period, no drift); stepped, each wait emits them (deterministic runs). */
#ifndef NUWORLD_PLATFORM_CLOCK_H
#define NUWORLD_PLATFORM_CLOCK_H

#include <stdbool.h>
#include <stdint.h>

#include <SDL3/SDL.h>

/* More periods late than this (sleep, debugger) and the clock resyncs to now with one edge instead of a burst. */
#define NW_CLOCK_MAX_LATE 4

typedef struct NwClockTiming {
    uint64_t t0;     /* ns */
    uint64_t period; /* ns */
    uint64_t k;      /* edges since t0 */
} NwClockTiming;

/* A frame more than a period late starts the count from now. */
typedef struct NwPacer {
    uint64_t next; /* ns, 0 before the first frame */
} NwPacer;

uint64_t nw_pacer_next(uint64_t next, uint64_t now, uint64_t period);
/* hz 0: no cap. */
void nw_pacer_wait(NwPacer *p, unsigned hz);

unsigned nw_clock_due(NwClockTiming *t, uint64_t now);
uint64_t nw_clock_deadline(const NwClockTiming *t);

typedef enum NwClockMode {
    NW_CLOCK_REALTIME,
    NW_CLOCK_STEPPED,
} NwClockMode;

/* Before the waiters wake: on the clock thread in real time, on the caller's thread when stepped. */
typedef void (*NwClockEdge)(void *user, unsigned edges);

typedef struct NwClock {
    NwClockMode mode;
    NwClockTiming timing;
    NwClockEdge on_edge;
    void *user;
    SDL_Mutex *lock;
    SDL_Condition *cond;
    SDL_Thread *thread;
    uint64_t edges; /* under lock */
    uint64_t edge_ns; /* under lock: when the last edges came */
    uint64_t wakes; /* under lock: nw_clock_wake calls */
    bool quit;      /* under lock */
} NwClock;

bool nw_clock_start(NwClock *c, NwClockMode mode, unsigned hz, NwClockEdge on_edge, void *user);
void nw_clock_stop(NwClock *c);
uint64_t nw_clock_edges(NwClock *c);
/* The edges and the part of a period since the last of them (at most 1). */
double nw_clock_time(NwClock *c);
void nw_clock_step(NwClock *c, unsigned n);
/* timeout_ms -1: never; returns the edge count. Stepped, it emits the edge itself. */
uint64_t nw_clock_wait(NwClock *c, uint64_t seen, int32_t timeout_ms);
/* nw_clock_wait that never steps: a stepped clock moves only for the thread that runs on it. */
uint64_t nw_clock_watch(NwClock *c, uint64_t seen, int32_t timeout_ms);
void nw_clock_wake(NwClock *c);

#endif
