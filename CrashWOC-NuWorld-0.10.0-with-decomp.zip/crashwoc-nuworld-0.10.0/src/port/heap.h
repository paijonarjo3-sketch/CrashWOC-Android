/* Game heaps hold only retail's bytes; a load's host records and GPU objects live beside, owned by its heap range. */
#ifndef NUWORLD_PORT_HEAP_H
#define NUWORLD_PORT_HEAP_H

#include <stdbool.h>
#include <stddef.h>

#include "gfx/packet.h"

typedef struct NwHeapSide NwHeapSide;

/* at: where retail keeps it (a heap address), NULL when the loader does not know. */
typedef struct NwHeapRec {
    void *host;
    size_t size;
    const void *at;
} NwHeapRec;

/* A load's host records, before it owns a range. */
NwHeapSide *nw_heap_side(void);

void *nw_heap_side_new(NwHeapSide *side, size_t size, size_t align);
/* The host record of retail's record at the heap address at. */
void *nw_heap_side_at(NwHeapSide *side, size_t size, size_t align, const void *at);

/* Freed with side's records by the job free, after the frames that draw it. */
void nw_heap_side_gpu(NwHeapSide *side, NwGpuOp free, void *obj);

/* side owns [lo, hi) of a game heap; the records of every other load whose range it overlaps are freed. */
void nw_heap_side_own(NwHeapSide *side, const void *lo, const void *hi);
/* Frees the load whose record holds host now, as a later load over its range would. */
void nw_heap_release(const void *host);

/* The decomp's NW_SUPERBUFFER_ALLOC (nu_port.h): the superbuffer at retail's address modulo 0x1000. */
void *nw_superbuffer_alloc(int size, char *file, int line);
/* NuFileLoadBuffer caps loads at these buffers' ends (NW_LOAD_ROOM); room: bytes from p to its end, false outside. */
void nw_load_buffer(const void *lo, size_t size);
bool nw_load_buffer_room(const void *p, size_t *room);

/* The decomp's NW_HEAP_TWIN (nu_port.h): a zeroed host record of size bytes, owned by the heap's charge bytes at at. */
void *nw_heap_twin(void *at, size_t charge, size_t size, size_t align);

/* Bytes retail rewrites and the port does not (a DMA chain fixed in place): a hole in dump.c's PS2 view. */
void nw_heap_side_hole(NwHeapSide *side, const void *at, size_t size, const char *why);
/* The same for bytes no load owns. */
void nw_heap_hole(const void *at, size_t size, const char *why);
void nw_heap_each_hole(void (*fn)(const void *at, size_t size, const char *why, void *user), void *user);

/* The live record holding p, its end included unless another record starts there; else NULL. */
const NwHeapRec *nw_heap_find(const void *p);

size_t nw_heap_sides(size_t *bytes);
size_t nw_heap_gpu(void);

#endif
