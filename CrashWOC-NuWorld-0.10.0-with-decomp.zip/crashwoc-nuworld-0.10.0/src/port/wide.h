/* Hor+ widescreen read by the NW_WIDE seams (nu_port.h); changed only between game frames; untouched it is retail. */
#ifndef NUWORLD_PORT_WIDE_H
#define NUWORLD_PORT_WIDE_H

#define NW_WIDE_MIN (4.0f / 3.0f)
#define NW_WIDE_MAX (32.0f / 9.0f)

/* aspect: picture w/h, clamped to NW_WIDE_MIN..NW_WIDE_MAX; hud: widest w/h the HUD spreads to, 0 for the edges. */
void nw_wide_set(float aspect, float hud);
/* The GS frame's width: 640 at 4:3, even so that its centre is a whole pixel. Any thread. */
int nw_wide_width(void);
/* Asks the game thread for nw_wide_set(aspect, hud) at its next frame; the last request wins. Any thread. */
void nw_wide_request(float aspect, float hud);
/* Draw radii and the enemies' spawn radius in percent of retail's, from the next nw_wide_poll. Any thread. */
void nw_wide_draw_distance(int percent);
/* Game thread, at a frame's end (NuRndrSwapScreen) outside a background load: applies a pending request. */
void nw_wide_poll(void);
/* The VU0 clip test's box: whether it is inside retail's 4:3 frustum, for NW_WIDE_SEEN. */
void nw_wide_clip(int retail_visible);
/* NW_WIDE_HUD's shear (x gained per depth) for a HUD point at panel camera x, z; 0 inside retail's picture. */
float nw_wide_hud_shear(float x, float z);

#endif
