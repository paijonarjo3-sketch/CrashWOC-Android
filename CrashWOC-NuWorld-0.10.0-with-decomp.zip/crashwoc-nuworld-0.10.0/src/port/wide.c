#include "port/wide.h"

#include <math.h>
#include <stddef.h>
#include <string.h>

#include <SDL3/SDL.h>

#include "nu_port.h"
#include "gamelib/terrain.h"
#include "gfx/rndr.h"
#include "nu3d/nucamera.h"
#include "nu3d/nugscn.h"
#include "nu3d/numtl.h"
#include "nu3d/nuvport.h"
#include "numath/numtx.h"
#include "numath/nutrig.h"

extern int PS2_VCNTR_X, PS2_REZ_W;
extern TerrainSetType *CurTerr;
extern struct nugscn_s *world_scene[32];
extern s32 SWIDTH, MAXVPSIZEX, MAXVPSIZEY;
extern struct nucamera_s *pNuCam;
extern float PANEL3DMULX;
extern volatile s32 bgload_complete;
extern char vu_load_glass_mpg[], vu_load_water_mpg[], vu_load_wateruv_mpg[];

struct nw_wide_s nw_wide = {
    .k = 1.0f, .aspect = 0.75f, .width = 640, .hud = 1.0f, .draw = 1.0f, .draw2 = 1.0f, .distance = 1.0f
};

static SDL_AtomicInt nw_wide_shown = { 640 }; /* nw_wide.width for other threads */
static SDL_AtomicInt nw_wide_asked;
static SDL_AtomicInt nw_wide_asks[2];         /* its aspect and HUD reach, as float bits */
static SDL_AtomicInt nw_wide_distance_asked = { 100 }; /* percent of retail's */
static int nw_wide_distance = 100;
static float nw_wide_side = 1.0f; /* the widening's share of the draw radii */

static void nw_wide_draw(void)
{
    nw_wide.distance = (float)nw_wide_distance / 100.0f;
    float draw = nw_wide_side * nw_wide.distance;
    nw_wide.draw = draw;
    nw_wide.draw2 = draw * draw;
}

/* game/panel's HUD anchors in panel x (-1 to 1 spans retail's 4:3 at depth 1); PAUSEPANELX stays (nw_wide_vp). */
extern float WUMPAOBJSX, WUMPATXTSX, BONUSWUMPAOBJSX, BONUSWUMPATXTSX, LIVESOBJSX, LIVESTXTSX, BONUSLIVESOBJSX,
    BONUSLIVESTXTSX, NEWLIFEOBJSX, NEWBONUSLIFEOBJSX, PANELCRUNCHX, PANELSINKX, PANELBLIMPX, RUMBOSSBARX, ATMBOSSBARX,
    FIREBOSSBARX, PANELRINGX;
extern float PANELCRUNCHZ, PANELSINKZ, PANELBLIMPZ;
static const struct {
    float *x;
    float side;
} nw_wide_anchors[] = {
    { &WUMPAOBJSX, -1.0f },      { &WUMPATXTSX, -1.0f },   { &BONUSWUMPAOBJSX, -1.0f }, { &BONUSWUMPATXTSX, -1.0f },
    { &LIVESOBJSX, 1.0f },       { &LIVESTXTSX, 1.0f },    { &BONUSLIVESOBJSX, 1.0f },  { &BONUSLIVESTXTSX, 1.0f },
    { &NEWLIFEOBJSX, 1.0f },     { &NEWBONUSLIFEOBJSX, 1.0f }, { &PANELCRUNCHX, 1.0f }, { &PANELSINKX, 1.0f },
    { &PANELBLIMPX, 1.0f },      { &RUMBOSSBARX, 1.0f },   { &ATMBOSSBARX, 1.0f },      { &FIREBOSSBARX, 1.0f },
    { &PANELRINGX, 1.0f },
};
static const struct {
    const float *x, *z;
} nw_wide_heads[] = { { &PANELCRUNCHX, &PANELCRUNCHZ }, { &PANELSINKX, &PANELSINKZ }, { &PANELBLIMPX, &PANELBLIMPZ } };
#define NW_WIDE_HEAD_IN 0.08f /* how much less the panel heads move out, so the picture's edge does not cut them */

/* A panel head moves out a little less, over its depth, since the screen takes panel x over depth */
static float nw_wide_out(const float *x, float h)
{
    float out = h - 1.0f;
    for (size_t i = 0; i < sizeof(nw_wide_heads) / sizeof(nw_wide_heads[0]); i++) {
        if (nw_wide_heads[i].x == x) {
            return (out - (out < NW_WIDE_HEAD_IN ? out : NW_WIDE_HEAD_IN)) * *nw_wide_heads[i].z;
        }
    }
    return out;
}

void nw_wide_set(float aspect, float hud)
{
    float a = aspect > NW_WIDE_MIN ? aspect < NW_WIDE_MAX ? aspect : NW_WIDE_MAX : NW_WIDE_MIN;
    int width = 2 * (int)lroundf(320.0f * a / NW_WIDE_MIN);
    /* k from the rounded width: the camera then matches the frame's pixels exactly */
    float k = width / 640.0f;
    /* The HUD's x reach: the edges up to hud's aspect, at most the picture's */
    float h = hud > 0.0f ? 2 * (int)lroundf(320.0f * hud / NW_WIDE_MIN) / 640.0f : k;
    h = h < 1.0f ? 1.0f : h > k ? k : h;
    /* Each anchor moves out by the HUD's extra reach, so an icon and its count keep their spacing */
    for (size_t i = 0; i < sizeof(nw_wide_anchors) / sizeof(nw_wide_anchors[0]); i++) {
        float *x = nw_wide_anchors[i].x;
        *x += nw_wide_anchors[i].side * (nw_wide_out(x, h) - nw_wide_out(x, nw_wide.hud));
    }
    /* A radius r reaches depth r / sqrt(1 + zx^2) at the side edge: the draw radii grow to keep retail's edge depth. */
    float zx0 = tanf(0.375f) / 0.75f, zx = zx0 * k;
    nw_wide_side = sqrtf(1.0f + zx * zx) / sqrtf(1.0f + zx0 * zx0);
    nw_wide_distance = SDL_GetAtomicInt(&nw_wide_distance_asked);
    nw_wide = (struct nw_wide_s){ .k = k, .aspect = 0.75f / k, .width = width, .hud = h, .pvs_all = width > 640 };
    nw_wide_draw();
    SDL_SetAtomicInt(&nw_wide_shown, width);
}

int nw_wide_width(void)
{
    return SDL_GetAtomicInt(&nw_wide_shown);
}

void nw_wide_request(float aspect, float hud)
{
    int bits[2];
    memcpy(&bits[0], &aspect, sizeof(bits[0]));
    memcpy(&bits[1], &hud, sizeof(bits[1]));
    SDL_SetAtomicInt(&nw_wide_asks[0], bits[0]);
    SDL_SetAtomicInt(&nw_wide_asks[1], bits[1]);
    SDL_SetAtomicInt(&nw_wide_asked, 1);
}

void nw_wide_draw_distance(int percent)
{
    SDL_SetAtomicInt(&nw_wide_distance_asked, percent);
}

/* Recomputes what the game derived from the old width: SWIDTH, MAXVPSIZEX, aspect, MaxVP, targets, VU words. */
static void nw_wide_frame(int was)
{
    int w = nw_wide.width;
    PS2_REZ_W = SWIDTH = MAXVPSIZEX = w;
    if (pNuCam) {
        pNuCam->aspect = nw_wide.aspect;
    }
    NuVpSetSize((float)(MAXVPSIZEX << 4), (float)(MAXVPSIZEY << 3));
    nw_wide_vp(0);
    if (w == was) {
        return;
    }
    nw_ps2tx_frame_width(was, w);
    const unsigned char *glass = (unsigned char *)vu_load_glass_mpg, *water = (unsigned char *)vu_load_water_mpg,
                        *wateruv = (unsigned char *)vu_load_wateruv_mpg;
    for (struct numtl_s *m = NuMtlIterate(1); m; m = NuMtlIterate(0)) {
        if (m->rs.mpg == glass) {
            m->vuattr.f32[0] = ((w * 0.5f) * 16.0 - 32768.0) / (NuPower2(w) * 16.0);
            m->vuattr.f32[4] = 1.0 / (NuPower2(w) * 16.0);
            m->vuattr.f32[6] = (w - 1.0f) / NuPower2(w);
        } else if (m->rs.mpg == water || m->rs.mpg == wateruv) {
            m->vuattr.mtx44->_10 = 1.0 / (NuPower2(w) * 16.0);
            m->vuattr.mtx44->_12 = w;
        }
    }
}

void nw_wide_poll(void)
{
    int distance = SDL_GetAtomicInt(&nw_wide_distance_asked);
    if (distance != nw_wide_distance) {
        nw_wide_distance = distance;
        nw_wide_draw();
    }
    if (!bgload_complete || !SDL_CompareAndSwapAtomicInt(&nw_wide_asked, 1, 0)) {
        return;
    }
    int bits[2] = { SDL_GetAtomicInt(&nw_wide_asks[0]), SDL_GetAtomicInt(&nw_wide_asks[1]) };
    float ask[2];
    memcpy(ask, bits, sizeof(ask));
    int was = nw_wide.width;
    nw_wide_set(ask[0], ask[1]);
    nw_wide_frame(was);
}

/* While paused 1-25 the view's origin moves from the frame's left edge to retail's 4:3 area, where the panels are. */
void nw_wide_vp(int paused)
{
    struct nuviewport_s *vp = NuVpGetCurrentViewport();
    NuVpSetPosition((float)(((PS2_VCNTR_X - (nw_wide.width >> 1)) << 4) + ((nw_wide.width - 640) << 3) * paused / 25),
                    (float)vp->y);
}

int nw_wide_vp_x(void)
{
    return NuVpGetCurrentViewport()->x - ((PS2_VCNTR_X - (nw_wide.width >> 1)) << 4);
}

/* Past retail's picture edge (PANEL3DMULX at depth 1) the x-over-depth ratio is capped at the edge's. */
float nw_wide_hud_shear(float x, float z)
{
    if (!(z > 0.0f)) {
        return 0.0f;
    }
    float r = x / z;
    return r - (r > PANEL3DMULX ? PANEL3DMULX : r < -PANEL3DMULX ? -PANEL3DMULX : r);
}

void nw_wide_hud(struct numtx_s *m)
{
    float s = nw_wide_hud_shear(m->_30, m->_32);
    if (s != 0.0f) {
        m->_00 += s * m->_02;
        m->_10 += s * m->_12;
        m->_20 += s * m->_22;
    }
}

static int nw_wide_special(const struct nuspecial_s *specials, int n, const struct nuinstance_s *inst)
{
    for (int i = 0; i < n; i++) {
        if (specials[i].instance == inst) {
            return 1;
        }
    }
    return 0;
}

/* A hidden instance animates while the wider view draws it, unless the game reads where it is (CurTerr, specials). */
int nw_wide_anim(struct nuinstance_s *inst, int test)
{
    if (test || !nw_wide.pvs_all || !inst->anim) {
        return test;
    }
    for (int i = 0; CurTerr && i < 128; i++) {
        if (CurTerr->platdata[i].curmtx == &inst->anim->mtx) {
            return test;
        }
    }
    for (int s = 0; s < 32; s++) {
        struct nugscn_s *sc = world_scene[s];
        if (sc && inst >= sc->instances && inst < sc->instances + sc->numinstance &&
            (nw_wide_special(sc->specials, sc->numspecial, inst) ||
             nw_wide_special(sc->exspecials, sc->numexspecials, inst))) {
            return test;
        }
    }
    return 1;
}

static int nw_wide_tests, nw_wide_retail;

void nw_wide_mark(void)
{
    nw_wide_tests = 0;
    nw_wide_retail = 0;
}

void nw_wide_clip(int retail_visible)
{
    nw_wide_tests++;
    nw_wide_retail |= retail_visible;
}

int nw_wide_seen(int drawn)
{
    return drawn && (nw_wide_tests == 0 || nw_wide_retail);
}
