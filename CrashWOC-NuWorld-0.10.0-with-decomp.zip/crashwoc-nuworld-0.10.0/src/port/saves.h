/* Replaces game/loadsave and drops the memory card: SaveSlot[2][2] shows a page of 4 saves, each written at once. */
#ifndef NUWORLD_PORT_SAVES_H
#define NUWORLD_PORT_SAVES_H

#include <stdint.h>

#include "save/savestore.h"

#define NW_SAVES_PAGE 4
#define NW_SAVES_PAGES (NW_SAVE_GAMES / NW_SAVES_PAGE)

struct game_s;

/* dir ends in a separator and is copied; NULL means none. Saves from elsewhere convert on first use. */
void nw_saves_init(const char *dir);
/* A raw PS2 save or a .ps2 card image; returns the saves made, 0 when it holds none, -1 with an SDL error. */
int nw_saves_import(const char *dir, const char *file);
/* Without the game running; picks give the 4 PS2 slots their games (nw_save_export). false with an SDL error. */
bool nw_saves_export(const char *dir, const char *card, const char *ps2_name, const int *picks, const void *icon,
                     size_t icon_len);
/* Any thread; NULL with an SDL error. */
const NwSaveRegistry *nw_saves_levels(void);

/* F1's import from a PS2 card; it only starts while no save screen shows. */
typedef enum NwSavesImport {
    NW_SAVES_IMPORT_IDLE,
    NW_SAVES_IMPORT_WAITING,
    NW_SAVES_IMPORT_RUNNING,
    NW_SAVES_IMPORT_DONE,
    NW_SAVES_IMPORT_FAILED,
} NwSavesImport;

typedef struct NwSavesImported {
    int saved[NW_SAVE_PS2_GAMES];
    int already[NW_SAVE_PS2_GAMES];
    char why[512];
} NwSavesImported;

/* Main thread; false while an import is waiting or running. */
bool nw_saves_import_games(const uint8_t *games);
NwSavesImport nw_saves_import_result(NwSavesImported *out);
bool nw_saves_screen(void);
/* Game thread, each frame. */
void nw_saves_import_poll(void);

int nw_saves_page(void);
void nw_saves_show(int page);
/* The pages the menus go through: up to the last save's page, and one more (at most NW_SAVES_PAGES). */
int nw_saves_pages(void);
/* Manual writes always refuse the automatic bank. */
void nw_saves_autos(bool automatic);
bool nw_saves_automatic(void);
bool nw_saves_has_autos(void);
/* Worker completion updates this cached presence flag; draw functions never enumerate the disk. */
void nw_saves_auto_changed(void);
bool nw_saves_pending(void);
void nw_saves_finish(void);
/* Shows an older generation in slot, leaving the disk untouched. */
bool nw_saves_previous(struct game_s *slot, int generation);
bool nw_saves_recovered(int i);
/* As of the last show, write or delete; -1 without saves. */
int nw_saves_latest(void);
/* When SaveSlot[i / 2][i % 2]'s game was saved; all zero for an empty slot or an unknown time. */
const NwSaveTime *nw_saves_time(int i);

/* Submissions only queue a snapshot or deletion: no disk write, enumeration or worker wait happens here. */
void nw_saves_write(struct game_s *slot);
void nw_saves_delete(struct game_s *slot);
void nw_saves_loaded(void);
/* A frame of the result screen; 1 once it has been shown its time. */
int nw_saves_shown(void);
int nw_saves_ok(void);
int nw_saves_any(void);

#endif
