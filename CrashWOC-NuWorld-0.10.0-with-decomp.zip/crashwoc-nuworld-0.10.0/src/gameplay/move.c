#include "game/creature.h"
#include "game/move.retail.h"
#include "gameplay/air.h"
#include "gameplay/fixes.h"
#include "gameplay/ground.h"
#include "gameplay/mech.h"
#include "gameplay/monkeybars.h"
#include "gameplay/slidespin.h"
#include "gameplay/submarine.h"

void MoveCRASH(struct creature_s *plr, struct nupad_s *pad)
{
    nw_ground_before(plr, pad);
    nw_air_before(plr, pad);
    nw_slide_spin_before(plr, pad);
    nw_fix_ground_slam(plr);
    MoveCRASH__retail(plr, pad);
    nw_air_move(plr, pad);
    nw_ground_after(plr);
    nw_slide_spin_after(plr);
}

void MoveCOCO(struct creature_s *plr, struct nupad_s *pad)
{
    nw_air_before(plr, pad);
    nw_fix_ground_slam(plr);
    MoveCOCO__retail(plr, pad);
    nw_air_move(plr, pad);
}

void MoveMECH(struct creature_s *plr, struct nupad_s *pad)
{
    nw_mech_before(plr, pad);
    MoveMECH__retail(plr, pad);
    nw_mech_after(plr, pad);
}

void AnimateCRASH(struct creature_s *plr)
{
    AnimateCRASH__retail(plr);
    nw_monkey_bars_animate(plr);
    nw_ground_animate(plr);
}

void AnimateCOCO(struct creature_s *plr)
{
    AnimateCOCO__retail(plr);
    nw_ground_animate(plr);
}

void MoveSUBMARINE(struct creature_s *plr, struct nupad_s *pad)
{
    nw_sub_turn(plr);
    nw_sub_fire_before(plr);
    MoveSUBMARINE__retail(plr, pad);
    nw_sub_fire_after(plr);
}
