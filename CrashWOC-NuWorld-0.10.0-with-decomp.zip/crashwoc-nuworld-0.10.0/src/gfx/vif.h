/* A port of nus_ps2.py. */
#ifndef NUWORLD_GFX_VIF_H
#define NUWORLD_GFX_VIF_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/* One vertex as the VU reads it, the layout of the VBO (28 bytes). */
typedef struct NwVifVertex {
    float pos[4];   /* VF06: x, y, z, w (V4-32: the normal's x with the ADC flag in its low half; V4-16: 0) */
    int16_t tex[4]; /* VF08: u, v (x4096), and the normal's y, z (x4096) when the unpack is V4-16 */
    uint8_t col[4]; /* VF31: r, g, b, a; 0x80 = 1.0 */
} NwVifVertex;

typedef struct NwVifMesh {
    NwVifVertex *verts;
    uint32_t *tris; /* 3 per triangle */
    uint32_t nverts, ntris, nbatches;
    uint32_t vcap, tcap;
    bool uvrow; /* the last geom unpacked its texcoords under STMOD 1: they add the material's STROW row */
} NwVifMesh;

typedef struct NwVifSprite {
    float pos[3];
    float size[2]; /* faceon: -4900 width, -2300 height (GS units before the divide); facey: half width, height */
    uint8_t col[4];
} NwVifSprite;

/* A face-on geom's sprites, all of one program. */
typedef struct NwVifSprites {
    NwVifSprite *sprites;
    uint32_t count, cap;
    bool facey; /* kicked at MSCAL 0x306 (facey), not 0x304 (faceon) */
} NwVifSprites;

/* Up to 8 joint/weight pairs, weights as the VU rounds them (FTOI15, 1.0 = 32768); one joint turns the normal. */
typedef struct NwVifSkinVertex {
    float pos[3];
    float nrm[3];
    float uv[2];
    uint16_t weight[8];
    uint8_t joint[8];
    uint8_t nrmjoint;
    uint8_t ndeltas;
    uint16_t pad;
    uint32_t delta; /* the first in NwVifSkin.deltas */
} NwVifSkinVertex;

/* A dupe vertex indexes its first occurrence; deltas are (dx, dy, dz, shape) as skinmod adds them. */
typedef struct NwVifSkin {
    NwVifSkinVertex *verts;
    uint32_t *tris; /* 3 per triangle */
    float (*deltas)[4];
    uint32_t nverts, ntris, ndeltas, nbatches, ndupes;
    uint32_t vcap, tcap, dcap;
    uint8_t maxjoint;
} NwVifSkin;

/* Appends one geom's batches; false (mesh unchanged) on a malformed chain or stream. */
bool nw_vif_decode(NwVifMesh *mesh, const void *geom, size_t size);
/* Each triangle its own three vertices, in batch order; false (mesh unchanged) on a malformed batch. */
bool nw_vif_otbatch(NwVifMesh *mesh, const void *batch, size_t size);
void nw_vif_free(NwVifMesh *mesh);
/* A face-on geom's sprites; false (s empty) on a malformed chain or stream. */
bool nw_vif_sprites(NwVifSprites *s, const void *geom, size_t size);
void nw_vif_sprites_free(NwVifSprites *s);
/* As NuPs2CreateSkinDma writes it, CALLs relative to the list; false (skin empty) on a malformed list or stream. */
bool nw_vif_skin(NwVifSkin *skin, const void *list, size_t size);
void nw_vif_skin_free(NwVifSkin *skin);

#endif
