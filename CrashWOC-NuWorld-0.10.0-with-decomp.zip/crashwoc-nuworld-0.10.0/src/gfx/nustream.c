/* Records live in t_base/t_ptr (retail's unused path-3 chain); raw packets via base and ptr are reported, not drawn. */
#include <stdio.h>
#include <string.h>

#include <SDL3/SDL.h>

#include "app.h"
#include "gfx/gem.h"
#include "gfx/interp.h"
#include "gfx/rndr.h"
#include "nu3d/nucamera.h"
#include "nu3d/numtl.h"
#include "nu3d/nustream.h"
#include "nu3d/nuvport.h"
#include "nucore/nuerror.h"
#include "numath/numtx.h"
#include "numath/nuvec.h"
#include "nu_port.h"
#include "platform/log.h"
#include "port/capture.h"
#include "port/game.h"

#define nustream_file "..\\nu2crash.ps2\\nu3d\\nustream.c"
#define NW_STREAMS 32
#define NW_ARENA_BLOCK 0x40000

void *NuMemAllocFn(int size, char *file, int line);

extern volatile int nuvideo_global_vbcnt;
extern float NuTrigTable[];
extern u8 *rndrstream_free;
extern struct rndrstream_s *rndrstream_2d;
extern struct rndrstream_s *rndrstream_fx;
extern char vu_load_faceon_mpg[], vu_load_tricu_mpg[], vu_load_tric_mpg[], vu_load_ptl_mpg[], vu_load_fx_mpg[],
    vu_load_fx2_mpg[];
extern struct nucamera_s global_camera;
extern struct numtx_s numtx_identity;

extern struct rndrstream_s *rndrstream_system;
extern struct rndrstream_s *rndrstream_3d_u;
extern struct rndrstream_s *rndrstream_mtl_sort;
extern struct rndrstream_s *rndrstream_faceon;
extern struct rndrstream_s *rndrstream_3d_l;
extern struct rndrstream_s *rndrstream_ptl;
extern struct rndrstream_s *rndrstream_ot_sort;
extern void *rndrstream_fx_microcode;

static struct rndrstream_s rndrstream_pool[NW_STREAMS];
static struct rndrstream_s *rndrstream_sorted[NW_STREAMS];
static int rndrstream_count;
static u8 *stream_outbuf[2];
static int stream_outbuf_size;
extern int rndrstream_buffid; /* flipped by NuRndrSwapStreamBuffers */
#define rndrstream_buffer_index rndrstream_buffid

/* Blocks never move; one arena per output buffer, so an unflushed stream keeps its records across a swap as retail. */
typedef struct NwBlock {
    struct NwBlock *next;
    size_t used;
    _Alignas(16) unsigned char data[NW_ARENA_BLOCK];
} NwBlock;

typedef struct NwBig {
    struct NwBig *next;
    _Alignas(16) unsigned char data[];
} NwBig;

typedef struct NwArena {
    NwBlock *first, *cur;
    NwBig *big;
} NwArena;

static NwArena nw_arena[2];

struct NwViewSnap {
    NwView view;
    uint64_t frame; /* the packet it was copied to (nw_frame + 1), and where */
    uint32_t index;
};

struct NwLightSnap {
    NwLights lights;
    uint64_t frame;
    uint32_t index;
};

struct NwJointSnap {
    uint64_t frame;
    uint32_t index, n;
    _Alignas(16) float mtx[][16];
};

static NwView nw_view;
static NwViewSnap *nw_view_snap;   /* its copy in the arena; NULL after a change */
static NwLights nw_lights;
static NwLightSnap *nw_light_snap; /* its copy in the arena; NULL after a change */
static NwLights nw_spec, nw_fx;    /* the UV matrices of SetSpecularLight and SetFxMtx */
static NwLightSnap *nw_spec_snap, *nw_fx_snap;
static NwJointSnap *nw_joint_snap;
static const uint32_t *nw_blend;
static struct nuvec_s spec_light_dir = { 0.0f, 0.0f, 1.0f }; /* retail's data */
static struct nuvec_s spec_view_dir = { 0.0f, 0.0f, -1.0f };
static float nw_local[16];
static uint64_t nw_frame;
static const struct numtl_s **nw_snap_key; /* nw_rndr_snap's table, by material address */
static uint32_t *nw_snap_index;
static uint32_t nw_snap_cap;
static const struct rndrstream_s *nw_raw[64];
static unsigned nw_nraw;

void *nw_rndr_alloc(size_t size)
{
    NwArena *a = &nw_arena[rndrstream_buffer_index];
    size = (size + 15) & ~(size_t)15;
    if (size > NW_ARENA_BLOCK) {
        NwBig *b = size <= SIZE_MAX - sizeof(*b) ? SDL_calloc(1, sizeof(*b) + size) : NULL;
        if (!b) {
            NuErrorProlog(nustream_file, 0x324)("out of memory for the stream records");
        }
        b->next = a->big;
        a->big = b;
        return b->data;
    }
    if (!a->cur || a->cur->used + size > NW_ARENA_BLOCK) {
        NwBlock **next = a->cur ? &a->cur->next : &a->first;
        if (!*next && !(*next = SDL_calloc(1, sizeof(NwBlock)))) {
            NuErrorProlog(nustream_file, 0x324)("out of memory for the stream records");
        }
        a->cur = *next;
        a->cur->used = 0;
    }
    void *p = a->cur->data + a->cur->used;
    a->cur->used += size;
    return p;
}

static NwViewSnap *nw_view_now(void)
{
    if (!nw_view_snap) {
        nw_view_snap = nw_rndr_alloc(sizeof(*nw_view_snap));
        nw_view_snap->view = nw_view;
        nw_view_snap->frame = 0;
    }
    return nw_view_snap;
}

static NwLightSnap *nw_misc_now(int misc)
{
    NwLightSnap **snap = misc == 1 ? &nw_light_snap : misc == 2 ? &nw_spec_snap : misc == 0x40 ? &nw_fx_snap : NULL;
    if (snap && !*snap) {
        *snap = nw_rndr_alloc(sizeof(**snap));
        (*snap)->lights = misc == 1 ? nw_lights : misc == 2 ? nw_spec : nw_fx;
        (*snap)->frame = 0;
    }
    return snap ? *snap : NULL;
}

void nw_rndr_blend(const uint32_t *weights)
{
    nw_blend = weights;
}

struct numtx_s *nw_rndr_joints(uint32_t n)
{
    NwJointSnap *j = nw_rndr_alloc(sizeof(*j) + (size_t)n * sizeof(j->mtx[0]));
    j->frame = 0;
    j->n = n;
    nw_joint_snap = j;
    return (struct numtx_s *)j->mtx;
}

static uint32_t nw_model_next, nw_model_now, nw_model_last, nw_model_parts;
static struct numtx_s nw_model_wm;

void nw_rndr_model_begin(const struct numtx_s *wm)
{
    float det = wm->_00 * (wm->_11 * wm->_22 - wm->_12 * wm->_21) - wm->_01 * (wm->_10 * wm->_22 - wm->_12 * wm->_20) +
                wm->_02 * (wm->_10 * wm->_21 - wm->_11 * wm->_20);
    if (det < 0.0f) {
        nw_model_now = 0;
        return;
    }
    if (++nw_model_next == 0) {
        nw_model_next = 1;
    }
    nw_model_now = nw_model_last = nw_model_next;
    nw_model_parts = 0;
    nw_model_wm = *wm;
}

void nw_rndr_model_end(void)
{
    nw_model_now = 0;
}

uint32_t nw_rndr_silhouette(const struct numtx_s *quad, float *scale)
{
    uint32_t id = nw_model_last;
    const struct numtx_s *wm = &nw_model_wm;
    nw_model_last = 0;
    float ux = quad->_00 * quad->_00 + quad->_01 * quad->_01 + quad->_02 * quad->_02;
    float uz = quad->_20 * quad->_20 + quad->_21 * quad->_21 + quad->_22 * quad->_22;
    float wx = wm->_00 * wm->_00 + wm->_01 * wm->_01 + wm->_02 * wm->_02;
    if (!id || !nw_model_parts || ux <= 0.0f || uz <= 0.0f || wx <= 0.0f) {
        return 0;
    }
    float dx = wm->_30 - quad->_30, dy = wm->_31 - quad->_31, dz = wm->_32 - quad->_32;
    float u = (dx * quad->_00 + dy * quad->_01 + dz * quad->_02) / ux;
    float v = (dx * quad->_20 + dy * quad->_21 + dz * quad->_22) / uz;
    if (u < -1.0f || u > 1.0f || v < -1.0f || v > 1.0f) {
        return 0;
    }
    *scale = SDL_sqrtf(ux / wx);
    return id;
}

NwRecord *nw_rndr_record(NwCmdOp op, struct numtl_s *mtl, const void *mpg, int misc)
{
    NwRecord *r = nw_rndr_alloc(sizeof(*r));
    memset(r, 0, sizeof(*r));
    if (nw_model_now && (op == NW_CMD_DRAW || op == NW_CMD_DRAW_OT || op == NW_CMD_SKIN)) {
        r->cmd.silhouette = nw_model_now;
        nw_model_parts++;
    }
    r->cmd.op = (uint8_t)op;
    nw_interp_cmd(&r->cmd);
    r->cmd.material = mtl;
    r->cmd.mpg = mpg;
    memcpy(r->cmd.local, nw_local, sizeof(nw_local));
    r->view = nw_view_now();
    r->lights = nw_misc_now(misc);
    r->misc = (uint8_t)misc;
    r->joints = op == NW_CMD_SKIN ? nw_joint_snap : NULL;
    r->blend = op == NW_CMD_SKIN ? nw_blend : NULL;
    return r;
}

void nw_rndr_push(struct rndrstream_s *stream, NwRecord *r)
{
    r->next = NULL;
    if (stream->t_ptr.voidptr) {
        ((NwRecord *)stream->t_ptr.voidptr)->next = r;
    } else {
        stream->t_base.voidptr = r;
    }
    stream->t_ptr.voidptr = r;
}

void nw_rndr_latch(NwRecord *r)
{
    r->view = nw_view_now();
    r->lights = nw_misc_now(r->misc);
}

static const void *nw_stream_mpg(const struct rndrstream_s *stream)
{
    return stream == rndrstream_fx ? rndrstream_fx_microcode : stream->mpg;
}

NwCmd *nw_rndr_cmd(struct rndrstream_s *stream, NwCmdOp op)
{
    NwRecord *r = nw_rndr_record(op, stream->mtl, nw_stream_mpg(stream), (int)(stream->attr & 0x43));
    nw_rndr_push(stream, r);
    return &r->cmd;
}

NwCmd *nw_rndr_verts(struct rndrstream_s *stream, NwVertsMode mode, uint32_t n, NwVuSpriteVertex **v)
{
    NwRecord *r = nw_rndr_record(NW_CMD_VERTS, stream->mtl, nw_stream_mpg(stream), (int)(stream->attr & 0x43));
    *v = nw_rndr_alloc(n * sizeof(**v));
    r->verts = *v;
    r->cmd.count = n;
    r->cmd.mode = (uint8_t)mode;
    nw_rndr_push(stream, r);
    return &r->cmd;
}

NwWaves *nw_rndr_waves(struct rndrstream_s *stream)
{
    NwRecord *r = nw_rndr_record(NW_CMD_WAVES, stream->mtl, nw_stream_mpg(stream), (int)(stream->attr & 0x43));
    NwWaves *w = nw_rndr_alloc(sizeof(*w));
    r->waves = w;
    nw_rndr_push(stream, r);
    return w;
}

NwZClut *nw_rndr_zclut(NwCmd *c)
{
    NwRecord *r = (NwRecord *)c;
    NwZClut *z = nw_rndr_alloc(sizeof(*z));
    memset(z, 0, sizeof(*z));
    r->zclut = z;
    return z;
}

NwCmd *nw_rndr_particles(struct rndrstream_s *stream, uint32_t n, NwPtlList **list, NwPtl **ptls)
{
    NwRecord *r = nw_rndr_record(NW_CMD_PARTICLES, stream->mtl, nw_stream_mpg(stream), (int)(stream->attr & 0x43));
    *list = nw_rndr_alloc(sizeof(**list));
    *ptls = nw_rndr_alloc(n * sizeof(**ptls));
    r->ptllist = *list;
    r->ptls = *ptls;
    r->cmd.count = n;
    nw_rndr_push(stream, r);
    return &r->cmd;
}

NwVuSpriteVertex *nw_rndr_quad(NwVuSpriteVertex *v, const NwVuSpriteVertex q[4])
{
    static const int strip[6] = { 0, 1, 2, 1, 2, 3 };
    for (int k = 0; k < 6; k++) {
        v[k] = q[strip[k]];
    }
    return v + 6;
}

/* Reported once per stream. */
static void nw_rndr_raw(const struct rndrstream_s *stream)
{
    for (unsigned i = 0; i < nw_nraw; i++) {
        if (nw_raw[i] == stream) {
            return;
        }
    }
    if (nw_nraw < SDL_arraysize(nw_raw)) {
        nw_raw[nw_nraw++] = stream;
    }
    nw_log_warn(NW_LOG_GFX, "stream %p (drawpri 0x%08x) holds packets the port does not draw",
                (const void *)stream, stream->drawpri);
}

void nw_rndr_splice(struct rndrstream_s *dst, struct rndrstream_s *src)
{
    if (src->base.voidptr && src->ptr.voidptr != src->base.voidptr) {
        nw_rndr_raw(src);
    }
    if (!src->t_base.voidptr) {
        return;
    }
    if (dst->t_ptr.voidptr) {
        ((NwRecord *)dst->t_ptr.voidptr)->next = src->t_base.voidptr;
    } else {
        dst->t_base.voidptr = src->t_base.voidptr;
    }
    dst->t_ptr.voidptr = src->t_ptr.voidptr;
    src->t_base.voidptr = src->t_ptr.voidptr = NULL;
}

NwPacket *nw_rndr_packet(void)
{
    return nw_packet_building();
}

unsigned nw_rndr_raw_streams(void)
{
    return nw_nraw;
}

static void nw_rndr_emit(struct rndrstream_s *stream)
{
    for (NwRecord *r = stream->t_base.voidptr; r; r = r->next) {
        NwViewSnap *v = (NwViewSnap *)r->view;
        NwCmd *c = nw_packet_cmd(nw_packet_building());
        if (v->frame != nw_frame + 1) {
            NwView *copy = nw_packet_view(nw_packet_building(), &v->index);
            if (copy) {
                *copy = v->view;
                v->frame = nw_frame + 1;
            }
        }
        NwLightSnap *l = (NwLightSnap *)r->lights;
        if (l && l->frame != nw_frame + 1) {
            NwLights *copy = nw_packet_light(nw_packet_building(), &l->index);
            if (copy) {
                *copy = l->lights;
                l->frame = nw_frame + 1;
            }
        }
        if (c) {
            *c = r->cmd;
            c->view = v->index;
            c->light = l ? l->index : NW_LIGHT_NONE;
            uint32_t *idx = r->idx ? nw_packet_idx(nw_packet_building(), r->cmd.count, &c->first) : NULL;
            if (idx) {
                memcpy(idx, r->idx, r->cmd.count * sizeof(*idx));
            }
            NwVuSpriteVertex *verts = r->verts ? nw_packet_verts(nw_packet_building(), r->cmd.count, &c->first) : NULL;
            if (verts) {
                memcpy(verts, r->verts, r->cmd.count * sizeof(*verts));
            } else if (r->verts) {
                c->count = 0;
            }
            NwZClut *zclut = r->zclut ? nw_packet_zclut(nw_packet_building(), &c->zclut) : NULL;
            if (zclut) {
                *zclut = *r->zclut;
                c->zclut++;
            } else if (r->zclut) {
                c->count = 0;
            }
            NwPtlList *list = r->ptllist ? nw_packet_ptllist(nw_packet_building(), &c->ptllist) : NULL;
            NwPtl *ptls = list ? nw_packet_ptls(nw_packet_building(), r->cmd.count, &c->first) : NULL;
            if (ptls) {
                *list = *r->ptllist;
                memcpy(ptls, r->ptls, r->cmd.count * sizeof(*ptls));
            } else if (r->ptllist) {
                c->count = 0;
            }
            NwWaves *waves = r->waves ? nw_packet_waves(nw_packet_building(), &c->first) : NULL;
            if (waves) {
                *waves = *r->waves;
            } else if (r->waves) {
                c->first = UINT32_MAX;
            }
            NwJointSnap *j = (NwJointSnap *)r->joints;
            if (j && j->n && j->frame != nw_frame + 1) {
                float(*copy)[16] = nw_packet_joints(nw_packet_building(), j->n, &j->index);
                if (copy) {
                    memcpy(copy, j->mtx, j->n * sizeof(j->mtx[0]));
                    j->frame = nw_frame + 1;
                }
            }
            if (j) {
                c->first = j->index;
                c->count = j->n;
            }
            uint32_t n = r->blend ? r->blend[5] : 0;
            float *w = n ? nw_packet_weights(nw_packet_building(), n, &c->weights) : NULL;
            c->nweights = w ? n : 0;
            if (w) {
                memcpy(w, r->blend + 6, n * sizeof(*w));
            }
        }
    }
    if (stream->base.voidptr && stream->ptr.voidptr != stream->base.voidptr) {
        nw_rndr_raw(stream);
    }
}

void NuRndrStreamResetStreams(int flag)
{
    for (int i = 0; i < rndrstream_count; i++) {
        rndrstream_pool[i].mtl = 0;
        NuRndrStreamResetStream(&rndrstream_pool[i], flag);
    }
    rndrstream_fx_microcode = vu_load_fx_mpg;
}

/* Retail also opens the system stream with a PRMODECONT; the port draws by records. */
void NuRndrInitStreams(void)
{
    rndrstream_free = stream_outbuf[rndrstream_buffer_index];
    NwArena *a = &nw_arena[rndrstream_buffer_index];
    a->cur = NULL;
    while (a->big) {
        NwBig *next = a->big->next;
        SDL_free(a->big);
        a->big = next;
    }
    nw_view_snap = NULL;
    nw_light_snap = NULL;
    nw_spec_snap = NULL;
    nw_fx_snap = NULL;
    nw_joint_snap = NULL;
    nw_blend = NULL;
    nw_packet_reset(nw_packet_building());
    nw_frame++;
    NuRndrStreamResetStreams(1);
}

struct rndrstream_s *NuRndrStreamAllocStream(unsigned int sortkey, void *mpgtag, unsigned int flags)
{
    if (rndrstream_count >= NW_STREAMS) {
        return 0;
    }
    struct rndrstream_s *stream = &rndrstream_pool[rndrstream_count];
    memset(stream, 0, sizeof(*stream));
    stream->mpg = mpgtag;
    stream->attr = flags;
    stream->drawpri = sortkey;
    NuRndrStreamResetStream(stream, 1);
    rndrstream_sorted[rndrstream_count] = stream;
    for (int i = 0; i < rndrstream_count; i++) {
        if (sortkey >= rndrstream_sorted[i]->drawpri) {
            memmove(&rndrstream_sorted[i + 1], &rndrstream_sorted[i], (rndrstream_count - i) * sizeof(stream));
            rndrstream_sorted[i] = stream;
            break;
        }
    }
    rndrstream_count++;
    return stream;
}

void NuRndrStreamInit(int size)
{
    rndrstream_count = 0;
    stream_outbuf[0] = NuMemAllocFn(size, nustream_file, 0x207);
    stream_outbuf[1] = NuMemAllocFn(size, nustream_file, 0x208);
    stream_outbuf_size = size;
    rndrstream_system = NuRndrStreamAllocStream(0x7FFFFFFF, 0, 0);
    rndrstream_mtl_sort = NuRndrStreamAllocStream(0x1000000, 0, 0x3D);
    rndrstream_faceon = NuRndrStreamAllocStream(0x1000000, vu_load_faceon_mpg, 0x3C);
    rndrstream_3d_u = NuRndrStreamAllocStream(0x10000000, vu_load_tricu_mpg, 0x3C);
    rndrstream_3d_l = NuRndrStreamAllocStream(0x10000000, vu_load_tric_mpg, 0x3D);
    rndrstream_2d = NuRndrStreamAllocStream(0x100000, 0, 0x10);
    rndrstream_ptl = NuRndrStreamAllocStream(0xFFFFFF, vu_load_ptl_mpg, 0x3C);
    rndrstream_fx = NuRndrStreamAllocStream(0xFFFFFF, vu_load_fx_mpg, 0x3C);
    rndrstream_ot_sort = NuRndrStreamAllocStream(0xFFFFFF, 0, 0x3D);
    rndrstream_buffer_index = 0;
    memset(stream_outbuf[0], 0, size);
    memset(stream_outbuf[1], 0, size);
    NuRndrInitStreams();
}

/* Appends streams in drawpri order (retail's sortstreams_enabled is 1); the pool streams start over. */
void NuRndrStreamFlush(void)
{
    if (rndrstream_free > stream_outbuf[rndrstream_buffer_index] + stream_outbuf_size) {
        NuErrorProlog(nustream_file, 0x324)("stream buffer overflow");
    }
    for (int i = 0; i < rndrstream_count; i++) {
        nw_rndr_emit(rndrstream_sorted[i]);
    }
    NuRndrStreamResetStreams(1);
}

/* Each material's state block read once, now, as the frame's DMA reads them after the frame is built. */
static void nw_rndr_snap(NwPacket *p)
{
    uint32_t cap = 64;
    while (cap < p->ncmds * 2) {
        cap *= 2;
    }
    if (cap > nw_snap_cap) {
        SDL_free(nw_snap_key);
        SDL_free(nw_snap_index);
        nw_snap_key = SDL_malloc(cap * sizeof(*nw_snap_key));
        nw_snap_index = SDL_malloc(cap * sizeof(*nw_snap_index));
        nw_snap_cap = nw_snap_key && nw_snap_index ? cap : 0;
        if (!nw_snap_cap) {
            NuErrorProlog(nustream_file, 0)("out of memory for the frame's materials");
        }
    }
    cap = nw_snap_cap;
    memset(nw_snap_key, 0, cap * sizeof(*nw_snap_key));
    for (uint32_t i = 0; i < p->ncmds; i++) {
        NwCmd *c = &p->cmds[i];
        const struct numtl_s *m = c->material;
        c->mtl = NW_MTL_NONE;
        if (!m) {
            continue;
        }
        uint32_t h = (uint32_t)(((uintptr_t)m >> 4) * 2654435761u) & (cap - 1);
        while (nw_snap_key[h] && nw_snap_key[h] != m) {
            h = (h + 1) & (cap - 1);
        }
        if (!nw_snap_key[h]) {
            NwMtlSnap *s = nw_packet_mtl(p, &nw_snap_index[h]);
            if (!s) {
                continue;
            }
            const NwStateBlock *sb = nw_rndr_state(m);
            nw_snap_key[h] = m;
            s->gs = sb->gs;
            memcpy(s->diffuse, sb->diffuse, sizeof(s->diffuse));
            memcpy(s->vu, sb->vuattr, sizeof(s->vu));
            memcpy(s->row, sb->vuattr + 9, sizeof(s->row));
            s->tex = nw_rndr_texture(m->tid);
            s->surf = nw_ps2tx_surf(m->tid);
            s->key = m;
            s->wrap = (uint8_t)((m->uanmmode == 2) | (m->vanmmode == 2) << 1);
            s->gem = nw_gem_find(m);
        }
        c->mtl = nw_snap_index[h];
    }
}

/* Retail sends the frame's DMA chain to VU1 here; the port hands the packet to the renderer instead. */
void NuRndrVu1Draw(void)
{
    nw_rndr_snap(nw_packet_building());
    nw_packet_building()->edge = nw_game_edges();
    nw_interp_publish(nw_packet_building());
    nw_capture_published(nw_packet_publish(nuvideo_global_vbcnt), nuvideo_global_vbcnt);
}

/* Room doubled for NuHGobjEvalDwa's pointer arrays in the stream buffer: host pointers are twice as wide. */
void *NuRndrStreamAlloc(int qwords)
{
    size_t size = (size_t)(qwords > 0 ? qwords : 0) * 32;
    void *p = nw_rndr_alloc(size);
    memset(p, 0, size);
    return p;
}

int NuRndrStreamAddMtl(struct rndrstream_s *stream, struct numtl_s *mtl)
{
    if (!NuMtlValid(mtl)) {
        return 0;
    }
    stream->mtl = mtl;
    return 1;
}

/* Each record takes the state retail's stream setters write into a stream (scissor, offset, matrices, VU 0x0C). */
void NuRndrStreamSetMisc(struct rndrstream_s *stream)
{
    (void)stream;
}

int NuRndrStreamSetViewMtx(struct rndrstream_s *stream)
{
    (void)stream;
    return 0;
}

int NuRndrStreamSetViewMtxScissorClip(struct rndrstream_s *stream)
{
    (void)stream;
    return 0;
}

int NuRndrStreamSetLocalMtx(struct rndrstream_s *stream)
{
    (void)stream;
    return 0;
}

/* Mode 1 is fx2, every other fx; retail calls the package into the fx stream when it changes. */
void NuRndrStreamFxMPG(int mode)
{
    rndrstream_fx_microcode = mode == 1 ? vu_load_fx2_mpg : vu_load_fx_mpg;
}

/* rndrstream_zfix is 0 in retail (NuRndrSetZFix is unreachable), so vm goes as it is. */
int NuRndrSetViewMtx(struct numtx_s *vm, struct numtx_s *pm, struct numtx_s *clip_pm)
{
    (void)pm;
    (void)clip_pm;
    memcpy(nw_view.vs, vm, sizeof(nw_view.vs));
    memcpy(nw_view.cam, &global_camera.mtx, sizeof(nw_view.cam));
    memcpy(nw_view.camscale, &global_camera.scale, sizeof(nw_view.camscale));
    nw_view_snap = NULL;
    return 1;
}

int NuRndrSetLocalMtx(struct numtx_s *mtx, int clip)
{
    (void)clip;
    memcpy(nw_local, mtx, sizeof(nw_local));
    return 1;
}

void NuRndrSetXYOffset(int x, int y)
{
    nw_view.xyoffset[0] = x;
    nw_view.xyoffset[1] = y;
    nw_view_snap = NULL;
}

void NuRndrSetScissor(int x0, int y0, int x1, int y1)
{
    nw_view.scissor[0] = x0;
    nw_view.scissor[1] = y0;
    nw_view.scissor[2] = x1;
    nw_view.scissor[3] = y1;
    nw_view_snap = NULL;
}

/* Retail keeps them transposed for the VU with colour alphas 0, 0, 1, which vu1init drops. */
int NuRndrSetDirectionalLights(struct nuvec_s *d0, struct nucolour3_s *c0, struct nuvec_s *d1, struct nucolour3_s *c1,
                               struct nuvec_s *d2, struct nucolour3_s *c2)
{
    const struct nuvec_s *d[3] = { d0, d1, d2 };
    const struct nucolour3_s *c[3] = { c0, c1, c2 };
    for (int i = 0; i < 3; i++) {
        nw_lights.dir[i][0] = d[i]->x;
        nw_lights.dir[i][1] = d[i]->y;
        nw_lights.dir[i][2] = d[i]->z;
        nw_lights.col[i][0] = c[i]->r;
        nw_lights.col[i][1] = c[i]->g;
        nw_lights.col[i][2] = c[i]->b;
    }
    nw_light_snap = NULL;
    return 1;
}

int NuRndrSetAmbientLight(struct nucolour3_s *colour)
{
    nw_lights.ambient[0] = colour->r;
    nw_lights.ambient[1] = colour->g;
    nw_lights.ambient[2] = colour->b;
    nw_light_snap = NULL;
    return 1;
}

/* Retail's UV matrix: aligned to the light/view half vector in camera space, offset 0.5; no program reads VU 0x10. */
int NuRndrSetSpecularLight(struct nuvec_s *dir, struct nucolour4_s *col)
{
    struct nuvec_s v;
    struct numtx_s m;
    const float half = 0.5f;
    (void)col;
    if (dir) {
        spec_light_dir = *dir;
    }
    NuVecInvMtxRotate(&v, &spec_light_dir, &global_camera.mtx);
    NuVecLerp(&v, &v, &spec_view_dir, half);
    NuVecMtxRotate(&v, &v, &global_camera.mtx);
    NuVecNorm(&v, &v);
    m = numtx_identity;
    NuMtxAlignZ(&m, &v);
    m._20 = -m._20;
    m._21 = -m._21;
    m._22 = -m._22;
    m._32 = m._03 = m._13 = m._23 = 0.0f;
    m._30 = half;
    m._31 = half;
    m._33 = 1.0f;
    memcpy(nw_spec.uv, &m, sizeof(nw_spec.uv));
    nw_spec_snap = NULL;
    return 1;
}

int NuRndrSetFxMtx(struct numtx_s *mtx)
{
    memcpy(nw_fx.uv, mtx, sizeof(nw_fx.uv));
    nw_fx_snap = NULL;
    return 1;
}

/* VU 0x16: camera yaw for facey, viewport size for faceon (width as retail's 4:3, nw_wide, keeping sprite shape). */
void FaceYDirStream(int angle)
{
    struct nuviewport_s *vp = NuVpGetCurrentViewport();
    nw_view.faceon[0] = NuTrigTable[(u16)(angle + 0x4000)];
    nw_view.faceon[1] = vp->width / nw_wide.k * 9.765625146e-05f;
    nw_view.faceon[2] = -NuTrigTable[(u16)angle];
    nw_view.faceon[3] = vp->height * 0.0002790178696f;
    nw_view_snap = NULL;
}
