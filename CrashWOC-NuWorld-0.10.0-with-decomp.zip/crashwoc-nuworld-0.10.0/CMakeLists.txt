cmake_minimum_required(VERSION 3.25)
project(crashwoc-nuworld VERSION 0.10.0 LANGUAGES C CXX)

if(NOT CMAKE_C_COMPILER_ID MATCHES "Clang")
  message(WARNING "${PROJECT_NAME} is built and tested with Clang (clang on Linux, CLANG64 on Windows).")
endif()

set(CMAKE_C_STANDARD 11)
set(CMAKE_C_STANDARD_REQUIRED ON)
set(CMAKE_C_EXTENSIONS ON)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
set(CMAKE_EXPORT_COMPILE_COMMANDS ON)

option(NUWORLD_SYSTEM_SDL3 "Use an installed SDL3 instead of building the pinned release" OFF)
option(NUWORLD_TESTS "Build the C tests (ctest)" ON)
option(NUWORLD_DECOMP "Generate and compile the decomp units (needs Python 3.11+ with libclang)" ON)
option(NUWORLD_FUZZ "Build the libFuzzer targets for the VFS readers and the loaders (clang on Linux)" OFF)
option(NUWORLD_SANITIZE "Build the port, the decomp and the tests with ASan and UBSan (clang)" OFF)
set(NUWORLD_TAG "BETA" CACHE STRING "Release tag in the build ID (empty for a release without one)")

if(CMAKE_C_SIMULATE_ID STREQUAL "MSVC")
  set(NW_MSVC_ABI ON)
  set(CMAKE_MSVC_RUNTIME_LIBRARY MultiThreadedDLL)
  add_compile_definitions(_CRT_SECURE_NO_WARNINGS _CRT_NONSTDC_NO_WARNINGS _USE_MATH_DEFINES)
  add_link_options(LINKER:/DEBUG LINKER:/INCREMENTAL:NO LINKER:/OPT:NOREF LINKER:/OPT:NOICF
    LINKER:/PDBALTPATH:%_PDB%)
  cmake_path(GET CMAKE_C_COMPILER PARENT_PATH nw_llvm_bin)
  find_program(NW_LLVM_LIB llvm-lib HINTS ${nw_llvm_bin} REQUIRED)
  foreach(lang C CXX)
    set(CMAKE_${lang}_ARCHIVE_CREATE "\"${NW_LLVM_LIB}\" /nologo /out:<TARGET> <OBJECTS>")
  endforeach()
  set(Python3_FIND_REGISTRY LAST)
  find_package(Python3 3.11 REQUIRED COMPONENTS Interpreter)
endif()

if(NUWORLD_SYSTEM_SDL3)
  find_package(SDL3 REQUIRED CONFIG)
elseif(NW_MSVC_ABI)
  include(FetchContent)
  FetchContent_Declare(SDL3
    URL https://github.com/libsdl-org/SDL/releases/download/release-3.4.16/SDL3-devel-3.4.16-VC.zip
    URL_HASH SHA256=1a784cb2a5c64d56fe7a62090fe9d242d9865f235e4ea9678f1a6ba4e693e7de)
  FetchContent_MakeAvailable(SDL3)
  find_package(SDL3 REQUIRED CONFIG PATHS ${sdl3_SOURCE_DIR}/cmake NO_DEFAULT_PATH)
  get_target_property(nw_sdl_dll SDL3::SDL3-shared IMPORTED_LOCATION)
  configure_file(${nw_sdl_dll} ${CMAKE_CURRENT_BINARY_DIR}/SDL3.dll COPYONLY)
else()
  include(FetchContent)
  set(SDL_SHARED OFF CACHE BOOL "" FORCE)
  set(SDL_STATIC ON CACHE BOOL "" FORCE)
  set(SDL_TEST_LIBRARY OFF CACHE BOOL "" FORCE)
  FetchContent_Declare(SDL3
    GIT_REPOSITORY https://github.com/libsdl-org/SDL.git
    GIT_TAG release-3.4.16
    GIT_SHALLOW TRUE
    SYSTEM)
  FetchContent_MakeAvailable(SDL3)
endif()

# After SDL: everything from here on, the decomp included.
if(NUWORLD_FUZZ)
  add_compile_options(-fsanitize=fuzzer-no-link)
endif()
if(NW_MSVC_ABI)
  add_compile_options(-gcodeview -gline-tables-only)
endif()
if(NUWORLD_SANITIZE)
  add_compile_options(-fsanitize=address,undefined -fno-sanitize-recover=undefined -fno-omit-frame-pointer)
  add_link_options(-fsanitize=address,undefined)
else()
  # Debug builds allocate nothing below 4 GB (src/platform/highheap.c); ASan keeps its own layout.
  add_compile_definitions($<$<CONFIG:Debug>:NW_HIGH_HEAP>)
endif()

include(FetchContent)
FetchContent_Declare(imgui
  GIT_REPOSITORY https://github.com/ocornut/imgui.git
  GIT_TAG v1.92.9b
  GIT_SHALLOW TRUE)
FetchContent_MakeAvailable(imgui)
add_library(nuworld_imgui STATIC
  ${imgui_SOURCE_DIR}/imgui.cpp
  ${imgui_SOURCE_DIR}/imgui_draw.cpp
  ${imgui_SOURCE_DIR}/imgui_tables.cpp
  ${imgui_SOURCE_DIR}/imgui_widgets.cpp
  ${imgui_SOURCE_DIR}/backends/imgui_impl_sdl3.cpp
  ${imgui_SOURCE_DIR}/backends/imgui_impl_opengl3.cpp)
target_include_directories(nuworld_imgui SYSTEM PUBLIC ${imgui_SOURCE_DIR} ${imgui_SOURCE_DIR}/backends)
target_compile_definitions(nuworld_imgui PUBLIC IMGUI_DISABLE_OBSOLETE_FUNCTIONS)
target_compile_options(nuworld_imgui PRIVATE -fno-exceptions -fno-rtti)
target_link_libraries(nuworld_imgui PUBLIC SDL3::SDL3 ${CMAKE_DL_LIBS})

# build/gen/<name>.c defines <name>[] and <name>_size.
function(nw_embed target name file)
  set(out ${CMAKE_CURRENT_BINARY_DIR}/gen/${name}.c)
  add_custom_command(OUTPUT ${out}
    COMMAND ${CMAKE_COMMAND} -DIN=${file} -DOUT=${out} -DNAME=${name} -P ${CMAKE_CURRENT_SOURCE_DIR}/cmake/embed.cmake
    DEPENDS ${file} ${CMAKE_CURRENT_SOURCE_DIR}/cmake/embed.cmake
    VERBATIM)
  target_sources(${target} PRIVATE ${out})
endfunction()
# Every PNG of a directory: build/gen/<name>.c defines <name>[] ({ name, data, size }) and <name>_count.
function(nw_embed_dir target name dir)
  file(GLOB files CONFIGURE_DEPENDS ${dir}/*.png)
  set(out ${CMAKE_CURRENT_BINARY_DIR}/gen/${name}.c)
  add_custom_command(OUTPUT ${out}
    COMMAND ${CMAKE_COMMAND} -DDIR=${dir} -DOUT=${out} -DNAME=${name} -P ${CMAKE_CURRENT_SOURCE_DIR}/cmake/embed_dir.cmake
    DEPENDS ${files} ${CMAKE_CURRENT_SOURCE_DIR}/cmake/embed_dir.cmake
    VERBATIM)
  target_sources(${target} PRIVATE ${out})
endfunction()
function(nw_symbols target)
  if(NOT NW_MSVC_ABI)
    return()
  endif()
  set(stem $<TARGET_FILE_DIR:${target}>/$<TARGET_FILE_BASE_NAME:${target}>)
  target_link_options(${target} PRIVATE LINKER:/MAP:${stem}.map)
  add_custom_command(TARGET ${target} POST_BUILD
    COMMAND ${Python3_EXECUTABLE} ${CMAKE_CURRENT_SOURCE_DIR}/tools/symtab.py ${stem}.map $<TARGET_FILE:${target}>
      ${stem}.sym
    VERBATIM)
endfunction()

add_executable(crashwoc-nuworld
  src/main.c
  src/platform/audio.c
  src/platform/crash.c
  src/platform/display.c
  src/platform/droptarget.c
  src/platform/gpu.c
  src/platform/log.c
  src/platform/platform.c
  src/gfx/gl.c
  src/gfx/vu.c
  src/frontend/debug.cpp
  src/frontend/help.c
  src/frontend/ui.cpp
  src/frontend/wizard.cpp)
set_target_properties(crashwoc-nuworld PROPERTIES OUTPUT_NAME NuWorld)
add_library(nuworld_fonts STATIC)
nw_embed(nuworld_fonts nw_font_regular ${CMAKE_CURRENT_SOURCE_DIR}/assets/fonts/AtkinsonHyperlegible-Regular.ttf)
nw_embed(nuworld_fonts nw_font_bold ${CMAKE_CURRENT_SOURCE_DIR}/assets/fonts/AtkinsonHyperlegible-Bold.ttf)
nw_embed(crashwoc-nuworld nw_beta_menu_png ${CMAKE_CURRENT_SOURCE_DIR}/assets/wizard/beta-menu.png)
# Window icon: the exe's icon resource on Windows (SDL takes the first one), a PNG set at runtime elsewhere.
if(WIN32)
  set(NW_RC_ICON ${CMAKE_CURRENT_SOURCE_DIR}/assets/branding/nuworld.ico)
  string(STRIP "${PROJECT_VERSION} ${NUWORLD_TAG}" NW_RC_VERSION)
  set(NW_RC_NAME NuWorld)
  set(NW_RC_DESCRIPTION "CrashWOC: NuWorld")
  configure_file(assets/branding/nuworld.rc.in ${CMAKE_CURRENT_BINARY_DIR}/gen/nuworld.rc @ONLY)
  target_sources(crashwoc-nuworld PRIVATE ${CMAKE_CURRENT_BINARY_DIR}/gen/nuworld.rc)
  # No console window; --console opens one (src/platform/log.c).
  set_target_properties(crashwoc-nuworld PROPERTIES WIN32_EXECUTABLE ON)
  target_link_libraries(crashwoc-nuworld PRIVATE ole32 shell32)
else()
  nw_embed(crashwoc-nuworld nw_icon_png ${CMAKE_CURRENT_SOURCE_DIR}/assets/branding/nuworld-icon-256.png)
endif()

target_include_directories(crashwoc-nuworld PRIVATE src)
target_compile_options(crashwoc-nuworld PRIVATE -Wall -Wextra $<$<COMPILE_LANGUAGE:CXX>:-fno-exceptions -fno-rtti>)
target_link_libraries(crashwoc-nuworld PRIVATE nuworld_frontend nuworld_gfx nuworld_imgui nuworld_port nuworld_fonts
  SDL3::SDL3)
if(MINGW)
  # Keep the release a single .exe: libc++ (Dear ImGui) linked in, not libc++.dll.
  target_link_options(crashwoc-nuworld PRIVATE -static-libstdc++)
endif()
if(NW_MSVC_ABI)
  include(cmake/crashpad.cmake)
  target_link_libraries(crashwoc-nuworld PRIVATE nuworld_crashpad)
endif()
nw_symbols(crashwoc-nuworld)

# Checked at every build.
set(nw_buildid ${CMAKE_CURRENT_BINARY_DIR}/gen/buildid.c)
add_custom_target(nuworld_buildid
  COMMAND ${CMAKE_COMMAND} -DSRC=${CMAKE_CURRENT_SOURCE_DIR} -DOUT=${nw_buildid} -DVERSION=${PROJECT_VERSION}
    -DTAG=${NUWORLD_TAG} -P ${CMAKE_CURRENT_SOURCE_DIR}/cmake/buildid.cmake
  BYPRODUCTS ${nw_buildid}
  VERBATIM)

add_library(nuworld_port STATIC
  src/hle/eedouble.c
  src/hle/eefpu.c
  src/platform/clock.c
  src/platform/http.c
  src/platform/update.c
  src/port/stub.c
  src/port/funcmap.c
  ${nw_buildid})
add_dependencies(nuworld_port nuworld_buildid)
target_include_directories(nuworld_port PUBLIC src)
target_compile_options(nuworld_port PRIVATE -Wall -Wextra)
target_link_libraries(nuworld_port PUBLIC SDL3::SDL3)
if(WIN32)
  target_link_libraries(nuworld_port PUBLIC winhttp)
endif()

set(NW_VFS_SOURCES
  src/platform/paths.c
  src/vfs/canon.c
  src/vfs/dat.c
  src/vfs/disc.c
  src/vfs/extract.c
  src/vfs/iso9660.c
  src/vfs/manifest.c
  src/vfs/rnc.c
  src/vfs/sha256.c
  src/vfs/verify.c
  src/vfs/vfs.c)
add_library(nuworld_vfs STATIC ${NW_VFS_SOURCES})
target_include_directories(nuworld_vfs PUBLIC src)
target_compile_options(nuworld_vfs PRIVATE -Wall -Wextra)
target_link_libraries(nuworld_vfs PUBLIC SDL3::SDL3)

add_library(nuworld_gfx STATIC
  src/gfx/gem.c
  src/gfx/gsc.c
  src/gfx/interp.c
  src/gfx/mtl.c
  src/gfx/packet.c
  src/gfx/tex.c
  src/gfx/vif.c
  src/gfx/vu1init.c)
target_include_directories(nuworld_gfx PUBLIC src)
target_compile_options(nuworld_gfx PRIVATE -Wall -Wextra)
target_link_libraries(nuworld_gfx PUBLIC nuworld_vfs)

add_library(nuworld_audio STATIC
  src/audio/libsd.c
  src/audio/nusound.c
  src/audio/sfx.c
  src/audio/spu2.c
  src/audio/vag.c)
target_include_directories(nuworld_audio PUBLIC src)
target_compile_options(nuworld_audio PRIVATE -Wall -Wextra)
target_link_libraries(nuworld_audio PUBLIC nuworld_vfs)

add_library(nuworld_frontend STATIC
  src/frontend/import.c
  src/frontend/presence.c
  src/frontend/settings.c
  src/platform/controls.c
  src/platform/discord.c
  src/platform/prompts.c)
target_include_directories(nuworld_frontend PUBLIC src)
target_compile_options(nuworld_frontend PRIVATE -Wall -Wextra)
target_link_libraries(nuworld_frontend PUBLIC nuworld_vfs nuworld_save)

set(NW_SAVE_SOURCES
  src/save/saveio.c
  src/save/saveworker.c
  src/save/ps2card.c
  src/save/savecodec.c
  src/save/savedoc.c
  src/save/savestore.c)
add_library(nuworld_save STATIC ${NW_SAVE_SOURCES})
target_include_directories(nuworld_save PUBLIC src)
target_compile_options(nuworld_save PRIVATE -Wall -Wextra)
target_link_libraries(nuworld_save PUBLIC SDL3::SDL3)

FetchContent_Declare(miniz
  GIT_REPOSITORY https://github.com/richgel999/miniz.git
  GIT_TAG 3.1.2
  GIT_SHALLOW TRUE
  SOURCE_SUBDIR none)
FetchContent_Declare(monocypher
  GIT_REPOSITORY https://github.com/LoupVaillant/Monocypher.git
  GIT_TAG 4.0.3
  GIT_SHALLOW TRUE
  SOURCE_SUBDIR none)
FetchContent_MakeAvailable(miniz monocypher)
file(WRITE ${CMAKE_CURRENT_BINARY_DIR}/gen/miniz/miniz_export.h "#define MINIZ_EXPORT\n")
add_library(nuworld_updater_deps STATIC
  ${miniz_SOURCE_DIR}/miniz.c
  ${miniz_SOURCE_DIR}/miniz_tdef.c
  ${miniz_SOURCE_DIR}/miniz_tinfl.c
  ${miniz_SOURCE_DIR}/miniz_zip.c
  ${monocypher_SOURCE_DIR}/src/monocypher.c
  ${monocypher_SOURCE_DIR}/src/optional/monocypher-ed25519.c)
target_include_directories(nuworld_updater_deps SYSTEM PUBLIC ${miniz_SOURCE_DIR}
  ${CMAKE_CURRENT_BINARY_DIR}/gen/miniz ${monocypher_SOURCE_DIR}/src ${monocypher_SOURCE_DIR}/src/optional)
target_compile_definitions(nuworld_updater_deps PUBLIC MINIZ_NO_STDIO MINIZ_NO_TIME MINIZ_NO_ZLIB_COMPATIBLE_NAMES)

add_library(nuworld_updater STATIC
  src/updater/apply.c
  src/updater/archive.c
  src/updater/job.c)
target_include_directories(nuworld_updater PUBLIC src)
target_compile_options(nuworld_updater PRIVATE -Wall -Wextra)
target_link_libraries(nuworld_updater PUBLIC nuworld_updater_deps nuworld_port nuworld_save nuworld_vfs)

add_executable(nuworld-updater src/updater/main.cpp src/frontend/ui.cpp src/gfx/gl.c)
set_target_properties(nuworld-updater PROPERTIES OUTPUT_NAME NuWorldUpdater)
target_include_directories(nuworld-updater PRIVATE src)
target_compile_options(nuworld-updater PRIVATE -Wall -Wextra $<$<COMPILE_LANGUAGE:CXX>:-fno-exceptions -fno-rtti>)
target_link_libraries(nuworld-updater PRIVATE nuworld_updater nuworld_imgui nuworld_fonts SDL3::SDL3)
if(WIN32)
  set(NW_RC_NAME NuWorldUpdater)
  set(NW_RC_DESCRIPTION "CrashWOC: NuWorld Updater")
  configure_file(assets/branding/nuworld.rc.in ${CMAKE_CURRENT_BINARY_DIR}/gen/nuworld-updater.rc @ONLY)
  target_sources(nuworld-updater PRIVATE ${CMAKE_CURRENT_BINARY_DIR}/gen/nuworld-updater.rc)
  set_target_properties(nuworld-updater PROPERTIES WIN32_EXECUTABLE ON)
endif()
if(MINGW)
  target_link_options(nuworld-updater PRIVATE -static-libstdc++)
endif()
add_dependencies(crashwoc-nuworld nuworld-updater)

if(NUWORLD_TESTS)
  enable_testing()
  add_executable(nuworld_test_vfs tests/c/test_vfs.c)
  target_compile_options(nuworld_test_vfs PRIVATE -Wall -Wextra)
  target_link_libraries(nuworld_test_vfs PRIVATE nuworld_frontend)
  add_test(NAME vfs COMMAND nuworld_test_vfs ${CMAKE_CURRENT_BINARY_DIR}/test-vfs)
  add_executable(nuworld_test_scene tests/c/test_scene.c)
  target_compile_options(nuworld_test_scene PRIVATE -Wall -Wextra)
  target_link_libraries(nuworld_test_scene PRIVATE nuworld_gfx)
  add_test(NAME scene COMMAND nuworld_test_scene ${CMAKE_CURRENT_BINARY_DIR}/test-scene)
  add_executable(nuworld_test_audio tests/c/test_audio.c)
  target_compile_options(nuworld_test_audio PRIVATE -Wall -Wextra)
  target_link_libraries(nuworld_test_audio PRIVATE nuworld_audio)
  add_test(NAME audio COMMAND nuworld_test_audio ${CMAKE_CURRENT_BINARY_DIR}/test-audio)
  add_test(NAME audio-retail COMMAND nuworld_test_audio retail)
  set_tests_properties(audio-retail PROPERTIES SKIP_RETURN_CODE 77)
  add_executable(nuworld_test_interp tests/c/test_interp.c)
  target_compile_options(nuworld_test_interp PRIVATE -Wall -Wextra)
  target_link_libraries(nuworld_test_interp PRIVATE nuworld_gfx)
  add_test(NAME interp COMMAND nuworld_test_interp)
  add_executable(nuworld_test_particle_gl tests/c/test_particle_gl.c src/gfx/gl.c src/gfx/vu.c)
  target_compile_options(nuworld_test_particle_gl PRIVATE -Wall -Wextra)
  target_link_libraries(nuworld_test_particle_gl PRIVATE nuworld_gfx)
  add_test(NAME particle-gl COMMAND nuworld_test_particle_gl)
  set_tests_properties(particle-gl PROPERTIES SKIP_RETURN_CODE 77)
  add_executable(nuworld_test_settings tests/c/test_settings.c)
  target_compile_options(nuworld_test_settings PRIVATE -Wall -Wextra)
  target_link_libraries(nuworld_test_settings PRIVATE nuworld_frontend)
  add_test(NAME settings COMMAND nuworld_test_settings ${CMAKE_CURRENT_BINARY_DIR}/test-settings)
  add_executable(nuworld_test_discord tests/c/test_discord.c)
  target_compile_options(nuworld_test_discord PRIVATE -Wall -Wextra)
  target_link_libraries(nuworld_test_discord PRIVATE nuworld_frontend)
  add_test(NAME discord COMMAND nuworld_test_discord)
  add_executable(nuworld_test_presence tests/c/test_presence.c)
  target_compile_options(nuworld_test_presence PRIVATE -Wall -Wextra)
  target_link_libraries(nuworld_test_presence PRIVATE nuworld_frontend)
  add_test(NAME presence COMMAND nuworld_test_presence)
  add_executable(nuworld_test_prompts tests/c/test_prompts.c)
  target_compile_options(nuworld_test_prompts PRIVATE -Wall -Wextra)
  target_link_libraries(nuworld_test_prompts PRIVATE nuworld_frontend)
  add_test(NAME prompts COMMAND nuworld_test_prompts)
  add_executable(nuworld_test_update tests/c/test_update.c)
  target_compile_options(nuworld_test_update PRIVATE -Wall -Wextra)
  target_link_libraries(nuworld_test_update PRIVATE nuworld_port)
  add_test(NAME update COMMAND nuworld_test_update)
  add_executable(nuworld_test_updater tests/c/test_updater.c)
  target_compile_options(nuworld_test_updater PRIVATE -Wall -Wextra)
  target_link_libraries(nuworld_test_updater PRIVATE nuworld_updater)
  add_test(NAME updater COMMAND nuworld_test_updater ${CMAKE_CURRENT_BINARY_DIR}/test-updater)
  add_executable(nuworld_test_log tests/c/test_log.c src/platform/crash.c src/platform/log.c)
  target_compile_options(nuworld_test_log PRIVATE -Wall -Wextra)
  target_link_libraries(nuworld_test_log PRIVATE nuworld_port ${CMAKE_DL_LIBS})
  nw_symbols(nuworld_test_log)
  add_test(NAME log COMMAND nuworld_test_log)
  if(NUWORLD_DECOMP)
    set(nw_crash_state "state: no frame drawn yet.*game thread: not started.*")
    set(nw_crash_last "last log lines:.*the report's last lines hold")
    set(nw_crash_segv "CRASH: [^\n]* at nw_crash_test_fault\\+0x[0-9a-f]+ .*stack:.*nw_crash_test\\+.*")
    if(NW_MSVC_ABI)
      set(nw_crash_dump "minidump: [^\n]*crashes[^\n]*reports.*")
      add_test(NAME crash-segv
        COMMAND ${CMAKE_COMMAND} -DEXE=$<TARGET_FILE:crashwoc-nuworld> -DDIR=${CMAKE_CURRENT_BINARY_DIR}/test-crash
          -P ${CMAKE_CURRENT_SOURCE_DIR}/cmake/check_crash.cmake)
      set_tests_properties(crash-segv PROPERTIES PASS_REGULAR_EXPRESSION
        "${nw_crash_segv}${nw_crash_state}${nw_crash_dump}${nw_crash_last}.*minidump file: [0-9]+ bytes")
    else()
      add_test(NAME crash-segv
        COMMAND crashwoc-nuworld --crash-test segv --data-dir ${CMAKE_CURRENT_BINARY_DIR}/test-crash)
      set_tests_properties(crash-segv PROPERTIES PASS_REGULAR_EXPRESSION
        "${nw_crash_segv}${nw_crash_state}${nw_crash_last}")
    endif()
    add_test(NAME crash-abort COMMAND crashwoc-nuworld --crash-test abort)
    set_tests_properties(crash-abort PROPERTIES PASS_REGULAR_EXPRESSION
      "CRASH: abort[^\n]* on thread main.*stack:.*nw_crash_test\\+.*${nw_crash_state}${nw_crash_last}")
    set(nw_crash_fatal "FATAL: crash test on thread main.*stack:.*nw_crash_fatal\\+.*nw_crash_test\\+.*")
    add_test(NAME crash-fatal COMMAND crashwoc-nuworld --crash-test fatal)
    set_tests_properties(crash-fatal PROPERTIES PASS_REGULAR_EXPRESSION
      "${nw_crash_fatal}${nw_crash_state}${nw_crash_last}")
  endif()
  add_executable(nuworld_test_display tests/c/test_display.c src/platform/display.c)
  target_include_directories(nuworld_test_display PRIVATE src)
  target_compile_options(nuworld_test_display PRIVATE -Wall -Wextra)
  target_link_libraries(nuworld_test_display PRIVATE SDL3::SDL3)
  add_test(NAME display COMMAND nuworld_test_display)
  add_executable(nuworld_test_gpu tests/c/test_gpu.c src/platform/gpu.c)
  target_include_directories(nuworld_test_gpu PRIVATE src)
  target_compile_options(nuworld_test_gpu PRIVATE -Wall -Wextra)
  target_link_libraries(nuworld_test_gpu PRIVATE SDL3::SDL3)
  add_test(NAME gpu COMMAND nuworld_test_gpu)
  add_executable(nuworld_test_savefile tests/c/test_savefile.c)
  add_library(nuworld_save_test STATIC ${NW_SAVE_SOURCES})
  target_include_directories(nuworld_save_test PUBLIC src)
  target_compile_definitions(nuworld_save_test PUBLIC NW_SAVE_TESTING)
  target_compile_options(nuworld_save_test PRIVATE -Wall -Wextra)
  target_link_libraries(nuworld_save_test PUBLIC SDL3::SDL3)
  target_compile_options(nuworld_test_savefile PRIVATE -Wall -Wextra)
  target_link_libraries(nuworld_test_savefile PRIVATE nuworld_save_test nuworld_vfs)
  add_test(NAME savefile COMMAND nuworld_test_savefile ${CMAKE_CURRENT_BINARY_DIR}/test-savefile)
endif()

if(NUWORLD_FUZZ)
  if(NOT CMAKE_C_COMPILER_ID MATCHES "Clang" OR MINGW)
    message(FATAL_ERROR "NUWORLD_FUZZ needs clang on Linux or macOS (libFuzzer does not support MinGW).")
  endif()
  set(nw_fuzz_flags -fsanitize=address,undefined -fno-sanitize-recover=undefined -fno-omit-frame-pointer)
  add_library(nuworld_vfs_fuzz STATIC ${NW_VFS_SOURCES} ${NW_SAVE_SOURCES} src/gfx/vif.c)
  target_include_directories(nuworld_vfs_fuzz PUBLIC src)
  target_compile_options(nuworld_vfs_fuzz PRIVATE -Wall -Wextra -fsanitize=fuzzer-no-link ${nw_fuzz_flags})
  target_link_libraries(nuworld_vfs_fuzz PUBLIC SDL3::SDL3)
  add_executable(nuworld_fuzz_vfs tests/fuzz/fuzz_vfs.c)
  target_compile_options(nuworld_fuzz_vfs PRIVATE -Wall -Wextra -fsanitize=fuzzer ${nw_fuzz_flags})
  target_link_options(nuworld_fuzz_vfs PRIVATE -fsanitize=fuzzer ${nw_fuzz_flags})
  target_link_libraries(nuworld_fuzz_vfs PRIVATE nuworld_vfs_fuzz)
  add_executable(nuworld_fuzz_seeds tests/fuzz/fuzz_seeds.c)
  target_include_directories(nuworld_fuzz_seeds PRIVATE tests/c)
  target_compile_options(nuworld_fuzz_seeds PRIVATE -Wall -Wextra)
  target_link_libraries(nuworld_fuzz_seeds PRIVATE nuworld_save nuworld_vfs)
  if(NUWORLD_TESTS)
    # Every seed once through the instrumented readers.
    set(nw_fuzz_seeds ${CMAKE_CURRENT_BINARY_DIR}/fuzz-seeds)
    set(nw_fuzz_loader_seeds ${CMAKE_CURRENT_BINARY_DIR}/fuzz-seeds-loaders)
    add_test(NAME fuzz_seeds COMMAND nuworld_fuzz_seeds ${nw_fuzz_seeds} ${nw_fuzz_loader_seeds})
    set_tests_properties(fuzz_seeds PROPERTIES FIXTURES_SETUP fuzz_corpus)
    add_test(NAME fuzz_vfs COMMAND nuworld_fuzz_vfs -runs=0 ${nw_fuzz_seeds})
    set_tests_properties(fuzz_vfs PROPERTIES FIXTURES_REQUIRED fuzz_corpus)
  endif()
endif()

if(NUWORLD_DECOMP)
  include(cmake/decomp.cmake)
endif()
